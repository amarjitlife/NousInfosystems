
package learnKotlin

//_________________________________________________________

fun playWithForLoop() {
	val collection = listOf( "First", "Second", "Third", "Nine", "Five" )

	// List Of Data: [ "First", "Second", "Third", "Nine", "Five" ]
	for( element in collection ) {
		println("$element")
	}

	println("\ncollection")
	var index = 0
	for( element in collection ) {
		println(" At $index Element: $element")
		index = index + 1
	}

	println("\ncollection.withIndex()")
	// collection.withIndex() Will Generate List Of Tuples
	//		Tuple Having 2 Members: Index and Element.
	// List Of Tuples: [ (0, "First"), (1, "Second"), (2, "Third"), (3, "Nine"), (4, "Five") ]

	// Picking Tuple Each Time From List Of Tuples
	//	and Unpacking/Decluttering Tuple Members To index And element 
	for( (index, element) in collection.withIndex() ) {
		println(" At $index Element: $element")
	}
}

// Function : playWithForLoop

// collection
//  At 0 Element: First
//  At 1 Element: Second
//  At 2 Element: Third
//  At 3 Element: Nine
//  At 4 Element: Five

// collection.withIndex()
//  At 0 Element: First
//  At 1 Element: Second
//  At 2 Element: Third
//  At 3 Element: Nine
//  At 4 Element: Five

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("Function : playWithForLoop")
	playWithForLoop()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/
