

class Experiments {
	public static void doSomething( int some ) {
		// {
			int some = 99;
			System.out.println( "Inside Function -> Some: " + some );		
		// }
	}

	public static void playWithLocalVariables() {
		int some = 10;
		doSomething( some );

		if ( some == 10 ) {
			// int some = 100;
			System.out.println( "Inside If -> Some: " + some );		
		}
		System.out.println( "Outside If -> Some: " + some );				
		
		{
			int i = 10;
		}

		for ( int i = 0 ; i < 10 ; i++ ) {
			System.out.println( i );					
		}
	}

	public static void main(String[] args) {
		System.out.println("Welcome Experiments!!!");

		System.out.println("\nFunction : playWithLocalVariables");
		playWithLocalVariables();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

