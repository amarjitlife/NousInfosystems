
package learnKotlin


//_________________________________________________________
// Function Type
//	(Int, Int) -> Int
fun sum( a: Int, b: Int ) : Int = a + b
fun sub( a: Int, b: Int ) : Int = a - b

// Higher Order Function
//		Functions Which Takes Function Arguments And/Or Returns Functions

//Function Type For calculator
//		(Int, Int, (Int, Int) -> Int ) -> Int
fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(a, b)
}

fun playWithCalculator() {
	val a = 40
	val b = 20

	var result: Int
	// ::sum Is Reference To Function sum
	result = calculator(a, b, ::sum )
	println("Result : $result ")

	// ::sub Is Reference To Function sub
	result = calculator(a, b, ::sub )
	println("Result : $result ")

	// Lambda Expression
	//		It Takes Two Int Arguments and Return Type Int
	val sumLamdba: (Int, Int) -> Int  = { x: Int, y: Int -> x + y }
	val subLamdba: (Int, Int) -> Int  = { x: Int, y: Int -> x - y }

	result = calculator(a, b, sumLamdba )
	println("Result : $result ")

	// ::sub Is Reference To Function sub
	result = calculator(a, b, subLamdba )
	println("Result : $result ")
}

// Function : playWithCalculator
// Result : 60 
// Result : 20 
//_________________________________________________________

data class Person(val name: String, val age: Int)

fun playWithLambdas() {
	val something: () -> Unit = { println(44) }
	something()

	val persons = listOf( Person("Gabbar", 34), 
		Person("Jay", 25), Person("Basanti", 30), Person("Veeru", 28))

	val names = persons.joinToString( separator = "  ",
			transform = { person: Person -> person.name })

	println( names )

	var result: Int

	val multiplyLambda0 = { x: Int, y: Int -> x * y }
	result = multiplyLambda0( 99, 10 )
	println("Result : $result ")

	var multiplyLambda : ( Int, Int ) -> Int

	multiplyLambda = { a: Int, b: Int -> a * b }
	result = multiplyLambda( 99, 10 )
	println("Result : $result ")		

	multiplyLambda = { a, b -> a * b }
	result = multiplyLambda( 99, 10 )
	println("Result : $result ")		

	multiplyLambda = { a, b -> 
		a * b 
	}
	result = multiplyLambda( 99, 10 )
	println("Result : $result ")		

	var doubleLamdba = { a : Int -> 2 * a }
	result = doubleLamdba( 11  )
	println("Result : $result ")		

	// Lamdba Taking Single Arugment: Argument Can Be Referred With it
	doubleLamdba = { it * 2 }
	result = doubleLamdba( 11  )
	println("Result : $result ")		

	val doubleLamdba0: (Int) -> Int = { it * 2 }
	result = doubleLamdba0( 11  )
	println("Result : $result ")		

	var squareLambda = { number: Int -> number * number }
	result = squareLambda( 11  )
	println("Result : $result ")		

	squareLambda = { it * it }
	result = squareLambda( 11  )
	println("Result : $result ")			
}

//_________________________________________________________

fun playWithLambdasAgain() {
	val a = 40
	val b = 20
	var result : Int

	fun operate(a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
		return operation(a, b)
	}

	fun addFunction(a: Int, b: Int) = a + b 
	val addLamdba: (Int, Int) -> Int  = { x: Int, y: Int -> x + y }

	result = operate(a, b, operation = addLamdba )
	println("Result : $result ")

	result = operate(a, b, operation = ::addFunction )
	println("Result : $result ")

	result = operate(a, b, operation = Int::plus )
	println("Result : $result ")	

	result = operate(a, b, operation = { x: Int, y: Int -> x + y } )
	println("Result : $result ")	

	result = operate(a, b, { 
		x: Int, y: Int -> 
			x + y 
	})
	println("Result : $result ")	


	result = operate(a, b, 
		operation = { x, y -> 
			x + y 
		}
	)
	println("Result : $result ")	


	result = operate(a, b, operation = { x, y -> x + y } )
	println("Result : $result ")	

	result = operate(a, b, { x, y -> x + y } )
	println("Result : $result ")	

	// Trailing Lambda Syntax
	//		If Function Takes Last Argument Lambda
	//			That Can Be Written Outside Of Function
	result = operate(a, b) { x, y -> x + y } 
	println("Result : $result ")	

	result = operate(a, b) { 
		x, y -> x + y 
	} 
	println("Result : $result ")	
}

//_________________________________________________________

// Higher Order Function
//		Function Return Function
fun chooseSteps( backward: Boolean ) : (Int) -> Int {
	// Function Type
	//		(Int) -> Int
	fun moveForward( start: Int ) : Int { return start + 1 }
	fun moveBackward( start: Int ) : Int { return start - 1 }

	// Returning Function Reference
	return if ( backward ) ::moveBackward else ::moveForward
}

fun playWithChooseStepFunction() {
	val something: (Int) -> Int = chooseSteps( backward = true )

	val result = something( 99 )
	println("Result : $result ")	

	val somethingAgain: (Boolean) -> (Int) -> Int = ::chooseSteps
	//What Is The Type Of somethingMore ????
	val somethingMore: (Int) -> Int = somethingAgain( false )
	val somethingOnceMore: Int = somethingMore( 88 )
	println( somethingOnceMore)
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithLambdas")
	playWithLambdas()

	println("\nFunction : playWithLambdasAgain")
	playWithLambdasAgain()

	println("\nFunction : playWithChooseStepFunction")
	playWithChooseStepFunction()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/

