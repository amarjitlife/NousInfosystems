/* Commands
For Compiling Kotlin Code
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar

For Running JAR File
java -jar functions.jar
*/

package learnKotlin

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// Generic Function
//		<T> Is Type PlaceHolder
//			i.e. T Will Be Substituted With Type At Compile Time
fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
 	// error: return type mismatch: expected 'kotlin.Unit', actual 'kotlin.String
	return result.toString()
}

fun playWithJoinToString() {
	// Based On Usage
	//		Compiler Will Infer <T> Placeholder To Be Substited With String Type
	// val strings: ArrayList<String>() = new ArrayList<String>( .... )
	val strings = listOf( "First", "Second", "Third", "Nine", "Five" )
	println( joinToString( strings, " ; ", " ( ", " ) " ) )

	// Based On Usage
	//		Compiler Will Infer <T> Placeholder To Be Substited With Integer Type
	val numbers = listOf( 990, 100, 500, 444, 111 )
	println( joinToString( numbers, " : ", " [ ", " ] " ) )	
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// Extension Functions

fun lastChar( string: String ) : Char {
	return string.get( string.length - 1 )
}

// error: platform declaration clash: The following declarations 
//		have the same JVM signature (lastChar(Ljava/lang/String;)C)
// fun String.lastChar() : Char {
// 		return this.get( this.length - 1 )
// }

// Extension Function
//		Mechanim To Add Functionality To Existing Classes/Types
//		lastCharacter Is An Extension Function On Type String
fun String.lastCharacter() : Char {
	//	Extension Function Can Access Class Context Using this
	return this.get( this.length - 1 )
}

fun playWithLastCharacter() {
	val greeting = "Good Morning!"

	println( lastChar( greeting) )
	println( lastChar( "Kotlin") )

	println( greeting.lastCharacter() )
	println( "Kotlin".lastCharacter() )
}

//_________________________________________________________

fun <T> Collection<T>.joinToStringExtention(
	separator: String,
	prefix: String,
	postfix: String
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
 	// error: return type mismatch: expected 'kotlin.Unit', actual 'kotlin.String
	return result.toString()
}

fun playWithJoinToStringExtension() {
	// Based On Usage
	//		Compiler Will Infer <T> Placeholder To Be Substited With String Type
	// val strings: ArrayList<String>() = new ArrayList<String>( .... )
	val strings = listOf( "First", "Second", "Third", "Nine", "Five" )
	println( strings.joinToStringExtention(" ; ", " ( ", " ) " ) )

	// Based On Usage
	//		Compiler Will Infer <T> Placeholder To Be Substited With Integer Type
	val numbers = listOf( 990, 100, 500, 444, 111 )
	println( numbers.joinToStringExtention(" : ", " [ ", " ] " ) )	
}

//_________________________________________________________
// POLYMORPHIC FUNCTION
//		MECHANISM: USING DEFAULT ARGUMENTS

// DEFAULT ARGUMENTS
//		Arguments With Default Values
fun <T> Collection<T>.join(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
 	// error: return type mismatch: expected 'kotlin.Unit', actual 'kotlin.String
	return result.toString()
}

fun playWithJoinExtension() {
	// Based On Usage
	//		Compiler Will Infer <T> Placeholder To Be Substited With String Type
	// val strings: ArrayList<String>() = new ArrayList<String>( .... )
	val strings = listOf( "First", "Second", "Third", "Nine", "Five" )
	println( strings.join( ) )
	println( strings.join(" ; " ) )
	println( strings.join(" ; ", " ( "  ) )
	
	// Argument Values Assigned To Arguments In Order
	println( strings.join(" ; ", " ( ", " ) " ) )

	// Based On Usage
	//		Compiler Will Infer <T> Placeholder To Be Substited With Integer Type
	val numbers = listOf( 990, 100, 500, 444, 111 )
	println( numbers.join( ) )
	println( numbers.join(" : ") )
	println( numbers.join(" : ", " [ " ) )	
	println( numbers.join(" : ", " [ ", " ] " ) )	

	// Kotlin Supports Named Arguments In Function Call
	//		Using Named Arguments
	// 			You Can Skip Some Of In Between The Defaults
	//		 	You Can Change Function Arguments Order During Call
	println( numbers.join( separator = " : " ) )
	println( numbers.join( separator = " : ", prefix = " [ " ) )	
	println( numbers.join( separator = " : ", postfix = " ] " ) )		
	println( numbers.join( postfix = " ] ", separator = " : ", prefix = " [ " ) )		

}

//_________________________________________________________

// Extension Properties
//		Mechanim To Add Functionality To Existing Classes/Types

// lastChar Is A IMMutable Extension Propery On Type String
//		IMMutable Property Can Have Only Getter
val String.lastChar : Char
	// Extension Property Can Access Class Context Using this
	// Immutable Property Can Have Getter	
	get() = this.get( this.length - 1 )

// lastChar Is A Mutable Extension Propery On Type StringBuilder
//		Mutable Property Can Have Getter and Setter
var StringBuilder.lastChar : Char
	get() {
		println("Getter Called...")
		return this.get( this.length - 1 )
	}
	set( value: Char ) {
		println("Setter Called...")
		this.setCharAt( length - 1, value )
	}

var StringBuilder.lastCharAgain : Char
	get() 				= this.get( this.length - 1 )
	set( value: Char ) 	= this.setCharAt( length - 1, value )

fun playWithExtensionProperties() {
	val greeting = "Good Morning!"

	println( greeting.lastChar )
	println( "Kotlin".lastChar )

	val lunch = StringBuilder("Good Afternoon! Let's have lunch!!!")
	println( lunch )	
	println( lunch.lastChar )
	lunch.lastChar = '#' 
	println( lunch.lastChar )
	println( lunch )	

	lunch.lastCharAgain = '$' 
	println( lunch.lastCharAgain )
	println( lunch )	
}

//_________________________________________________________
// LOCAL FUNCTIONS

fun moveTowardsZero( start: Int ) : Int {
	// Local Functions
	//		Functions Defined Inside A Function
	fun moveForward( start: Int ) : Int {
		return start + 1
	}

	fun moveBackward( start: Int ) = start - 1

	return if ( start > 0 ) moveBackward( start ) else moveForward( start )
}

fun playWithLocalFunctions() {
	println( moveTowardsZero( 10 ) )
	println( moveTowardsZero( -10 ) )
}

//_________________________________________________________

class User(val id: Int, val name: String, val address: String )

fun saveUser( user: User ) {
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User ${user.id}: Name Empty")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User ${user.id}: Address Empty")
	}

	// Logic For Saving User Will Come...
	println("Saving User: ${user.id} ${user.name}")
}

fun playWithSaveUser() {
	val gabbar 	= User(420, "Gabbar Singh", "Ramgarh")
	val basanti = User(100, "Basanti", "Ramgarh")

	saveUser( gabbar )
	saveUser( basanti )
}

//_________________________________________________________

// class User(val id: Int, val name: String, val address: String )

fun saveUserAgain( user: User ) {
	// Local Function: Function Defined Inside Function
	fun validate( user: User, value: String, field: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User ${user.id}: $field Empty")
		}
	}

	validate( user, user.name, "Name" )
	validate( user, user.address, "Address" )

	// Logic For Saving User Will Come...
	println("Saving User: ${user.id} ${user.name}")
}

fun playWithSaveUserAgain() {
	val gabbar 	= User(420, "Gabbar Singh", "Ramgarh")
	val basanti = User(100, "Basanti", "Ramgarh")

	saveUserAgain( gabbar )
	saveUserAgain( basanti )
}

//_________________________________________________________

// save Is A Extension Function On User Class/Type
fun User.save() {
	// Local Function: Function Defined Inside Function
	fun validate( user: User, value: String, field: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User ${this.id}: $field Empty")
		}
	}

	validate( this, this.name, "Name" )
	validate( this, this.address, "Address" )

	// Logic For Saving User Will Come...
	println("Saving User: ${this.id} ${this.name}")
}

fun playWithSaveExtension() {
	val gabbar 	= User(420, "Gabbar Singh", "Ramgarh")
	val basanti = User(100, "Basanti", "Ramgarh")

	gabbar.save()
	basanti.save()
}

//_________________________________________________________

fun parsePath( path: String ) {
	val directory = path.substringBeforeLast( "/" )
	val fullName = path.substringAfterLast( "/" )

	val fileName = fullName.substringBeforeLast( "." )
	val fileExtension = fullName.substringAfterLast( "." )

	println("Directory: $directory")
	println("Full Name: $fullName")
	println("File Name: $fileName")
	println("File Extension: $fileExtension")
}

fun multipleLineString() {
	val paragraph = """
		How are you doing?
		I am doing fine...
		Hale and Hearty!!!
		"""
	println( paragraph )
}

fun playWithStringFunctions() {
	parsePath("/home/Users/gabbar/chammabal/basanti.com")
	multipleLineString()
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithJoinExtension")
	playWithJoinExtension()

	println("\nFunction : playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction : playWithLocalFunctions")
	playWithLocalFunctions()

	println("\nFunction : playWithSaveUser")
	playWithSaveUser()

	println("\nFunction : playWithSaveUserAgain")
	playWithSaveUserAgain()

	println("\nFunction : playWithSaveExtension")
	playWithSaveExtension()

	println("\nFunction : playWithStringFunctions")
	playWithStringFunctions()
	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/
