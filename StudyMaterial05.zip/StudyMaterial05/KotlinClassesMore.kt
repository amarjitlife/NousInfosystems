
/* Commands
For Compiling Kotlin Code
kotlinc KotlinClassesMore.kt -include-runtime -d more.jar

For Running JAR File
java -jar more.jar
*/

package learnKotlin

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// class Person(val firstName: String, val lastName: String ) {
// open class Person(val firstName: String, val lastName: String ) {
// open class Person(open val firstName: String, open val lastName: String ) {
// 		open val fullName = "$firstName $lastName"
// }

open class Person( val firstName: String, val lastName: String ) {
	val fullName = "$firstName $lastName"
}

// class Student(val firstName: String, val lastName: String ) : Person(firstName, lastName) {
// class Student(override val firstName: String, override val lastName: String ) 
// 	: Person(firstName, lastName) {
// 		override val fullName = "$firstName $lastName"
// } 

data class Subject( val name: String, val grade: Char, val points: Double, val credits: Double)

open class Student( firstName: String, lastName: String ) : Person(firstName, lastName) {
	val passedSubjects: MutableList<Subject> = mutableListOf<Subject>()
	val failedSubjects: MutableList<Subject> = mutableListOf<Subject>()	

	fun recordGrade( subject: Subject ) {
		if ( subject.grade == 'F' ) failedSubjects.add( subject )
		else passedSubjects.add( subject )
	}

	open fun printGrades() {
		for ( subject in passedSubjects ) println( "  $subject")
		for ( subject in failedSubjects ) println( "  $subject")		
	}

	fun isPassed() : Boolean {
		return failedSubjects.size <= 2 
	}
} 


fun playWithClasses() {
	val gabbar = Person("Gabbar", "Singh")
	println( gabbar.fullName )

	val basanti = Person( firstName = "Basanti", lastName = "Chatty")
	println( basanti.fullName )	

	val veeru = Student("Veeru", "Dharam")
	println( veeru.fullName )

	val jay = Student("Jay", "Amitabh")
	println( jay.fullName )
}

fun playWithStudentGrades() {
	val gabbar = Student("Gabbar", "Singh")

	val decoit = Subject("Decoit", 'A', points = 9.0 , credits = 3.0 )
	//					Named Arugments
	val kiddnapping = Subject( name = "kiddnapping", grade = 'A' , points = 10.0, credits = 3.0)
	val shooting = Subject("Shooting", 'B', 8.0, credits = 4.0)

	gabbar.recordGrade( decoit )
	gabbar.recordGrade( kiddnapping )
	gabbar.recordGrade( shooting )
	println( gabbar.fullName )
	gabbar.printGrades() 

	val basanti = Student("Basanti", "Chatti")
	val english = Subject("English", 'C', points = 7.0, credits = 3.0 )
	basanti.recordGrade( english )
	println( basanti.fullName )
	basanti.printGrades()
}

// Function : playWithClasses
// Gabbar Singh
// Basanti Chatty
// null null
// null null

//_________________________________________________________

data class Game(val name: String, val grade: Char, val points: Double )

class StudentAthlete(firstName: String, lastName: String) : Student( firstName, lastName ) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGames( game: Game ) = gamesPlayed.add( game )

	override fun printGrades() {
		super.printGrades()
		for( game in gamesPlayed ) println("  $game")
	}
}


fun playWithStudentAthlete() {
	val gabbar = StudentAthlete("Gabbar", "Singh")

	val decoit = Subject("Decoit", 'A', points = 9.0 , credits = 3.0 )
	//					Named Arugments
	val kiddnapping = Subject( name = "kiddnapping", grade = 'A' , points = 10.0, credits = 3.0)
	val shooting = Game("Shooting", 'B', 8.0)

	gabbar.recordGrade( decoit )
	gabbar.recordGrade( kiddnapping )
	gabbar.recordGames( shooting )
	println( gabbar.fullName )
	gabbar.printGrades() 

	val basanti = StudentAthlete("Basanti", "Chatti")
	val english = Subject("English", 'C', points = 7.0, credits = 3.0 )
	val dancing = Game("Dancing", 'A', 10.0)

	basanti.recordGrade( english )
	basanti.recordGames( dancing )
	println( basanti.fullName )
	basanti.printGrades()
}

//_________________________________________________________

open class BandMember(firstName: String, lastName: String ) : Student( firstName, lastName ) {
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember( firstName, lastName ) {
	override val minimumPracticeTime: Int 
		get() { return 4 }
}

class FlutePlayer(firstName: String, lastName: String) : BandMember( firstName, lastName ) {
	override val minimumPracticeTime: Int 
		get() { return 3 }
}

fun playWithTypeCheck() {
	//	LHS  						=  RHS
	// Reference To Object ------->   Object [Allocated At Heap ]
	// Reference guitarPlayer Of Type GuitarPlayer Pointing To Object Of Type GuitarPlayer
	val guitarPlayer : GuitarPlayer = GuitarPlayer("Gabbar", "Singh")

	// is Type Check
	//	Doing Type Check Of Reference OR Object Where Reference Pointing
	//	is Type Check Does Checking Of OBJECT
	println( guitarPlayer is GuitarPlayer )
	println( guitarPlayer is BandMember )
	println( guitarPlayer is Student )
	println( guitarPlayer is Person )

	// Reference reference1 Of Type GuitarPlayer Pointing To Object Of Type GuitarPlayer	
	val reference1 = guitarPlayer
	// Reference reference2 Of Type BandMember Pointing To Object Of Type GuitarPlayer	
	val reference2: BandMember 	= guitarPlayer	
	// Reference reference3 Of Type Student Pointing To Object Of Type GuitarPlayer	
	val reference3: Student 	= guitarPlayer
	// Reference reference4 Of Type Person Pointing To Object Of Type GuitarPlayer	
	val reference4: Person 		= guitarPlayer

	println( reference1 is GuitarPlayer )
	println( reference1 is BandMember )
	println( reference1 is Student )
	println( reference1 is Person )

	println( reference2 is GuitarPlayer )
	println( reference2 is BandMember )
	println( reference2 is Student )
	println( reference2 is Person )

	println( reference3 is GuitarPlayer )
	println( reference3 is BandMember )
	println( reference3 is Student )
	println( reference3 is Person )

	// Reference shakira Of Type BandMember Pointing To Object Of Type BandMember	
	val shakira = BandMember("Shakira", "Waka Waka")
	println( shakira is GuitarPlayer )
	println( shakira is BandMember )
	println( shakira is Student )
	println( shakira is Person )

	val milkha = StudentAthlete("Milkha", "Singh" )
	println( milkha is Student )
	println( milkha is Person )
	println( milkha is GuitarPlayer )
	println( milkha is BandMember )	
}

//_________________________________________________________

interface Something {
	fun doSomething() = println("Something: Do Something")
}

interface Clickable {
	fun click() // Abstract Member Function: Function With ONLY Signature
	fun doFun() = println("Clickable: Do Fun!") // NOT A ABSTRACT Member Function
}

interface Focusable {
	fun focus() // Abstract Member Function: Function With Signature
}

class Button : Clickable, Focusable, Something {
	override fun click() = println("Button: click Called...")
	override fun focus() = println("Button: focus Called...")
	override fun doFun() = println("Button: Do Fun!")
	fun doMagic() = println("Button: Doing Magic...")

	override fun doSomething() {
		super.doSomething()
		println("Button1: Do Something!")
	}
}

fun playWithTypeCheckAgain() {
	val button = Button()

	println( button is Button )
	println( button is Clickable )
	println( button is Focusable )
	println( button is Something )
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

abstract class Mammal( val name: String, val birthDate: String ) {
	abstract fun consumeFood()
}


class Human( name: String, birthDate: String ) : Mammal( name, birthDate ) {
	override fun consumeFood() {
		println("Human: Consuming Food...")
	}

	fun createBirthCertificate() = println("Birth Certificate Created!")
}

fun playWithMammals() {
	val katrina = Human("Katrina Kaif", "10-10-10")
	katrina.consumeFood()
	katrina.createBirthCertificate()

	println( katrina is Human )
	println( katrina is Mammal )
}

//_________________________________________________________

sealed class Geometry {
	class Circle( val radius: Int ) : Geometry()
	class Square( val side: Int ) 	: Geometry()
	class Unknown( val size: Int ) 	: Geometry()
}

fun sizeOfGeometry( geometry: Geometry ) = when( geometry ) {
		is Geometry.Circle 	-> geometry.radius
		is Geometry.Square 	-> geometry.side
		is Geometry.Unknown -> geometry.size 
}

fun playWithGeometries() {
	val circle = Geometry.Circle( 10 )
	val square = Geometry.Square( 99 )

	println( sizeOfGeometry( circle ) )
	println( sizeOfGeometry( square ) )
}

//_________________________________________________________

//PRIMARY CONSTRUCTOR AND SECONDARY CONSTRUCTORS

// 				Primary Constructor
class PersonAgain(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
}

class PersonOnceAgain {
	val firstName: String = "Unknown"
	val lastName: String  = ""
	val fullName = "$firstName $lastName"
}

fun playWithConstructors() {
	val gabbar = PersonAgain("Gabbar", "Singh")
	println( gabbar.fullName )

	// val gabbar1 = PersonAgain()
	// println( gabbar1.fullName )

				   // DEFUALT CONSTRUCTOR
	val basanti = PersonOnceAgain()
	println( basanti.fullName )
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// BEST PRACTICE
//		Always Prefer Primary COnstructor With Default Arguments
//			Over Constructor Overloading

//				 Primary Constructor With Default Arguments
class ShapeBetter( var boundaryColor: String, var fillColor : String = "Unknown" ) {
	fun printData() {
		println("ShapeBetter :: boundaryColor = $boundaryColor, fillColor = $fillColor")
	}	
}

// SECONDARY CONSTRUCTORS
//		Constructor Overloading
open class Shape {
	var boundaryColor : String
	var fillColor : String

	// Secondary Constructor
	constructor( boundaryColor : String ) {
		this.boundaryColor = boundaryColor
		this.fillColor = "Uknonwn"
	} 

	// Secondary Constructor
	constructor( boundaryColor : String, fillColor : String ) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
	} 

	open fun printData() {
		println("Shape :: boundaryColor = $boundaryColor, fillColor = $fillColor")
	}
}

fun playWithShape() {
	val shape1 = Shape("Black")
	shape1.printData()

	val shape2 = Shape("Black", "Green")
	shape2.printData()

	val shape11 = ShapeBetter("Black")
	shape11.printData()

	val shape22 = ShapeBetter("Black", "Green")
	shape22.printData()
}

//_________________________________________________________

class Circle : Shape {
	var radius : Int

	// constructor( boundaryColor : String ) : super( boundaryColor ) {
	constructor( boundaryColor : String ) : this( boundaryColor, "Unknown", 0 ) {
	// constructor( boundaryColor : String ) {
		// error: explicit 'this' or 'super' call is required. There is no constructor in superclass that can be called without arguments

		// NOTE :: Following Is Redundunt Code If Following Constructor Called
		//		this( boundaryColor, "Unknown", 10 )
		this.boundaryColor = boundaryColor
		this.fillColor = "Unknown"
		this.radius = 0
	}

	constructor( boundaryColor : String, fillColor: String, radius: Int ) : super(boundaryColor, fillColor) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
		this.radius = radius
	}

	override fun printData() {
		println("Circle :: BoundryColor= $boundaryColor, FillColor = $fillColor, Radius = $radius")
	}
}

fun playWithShapeAndCircle() {
	val circle1 = Circle("Black")
	circle1.printData()

	// val circle2 = Circle("Black", "Red")
	// circle2.printData()

	val circle3 = Circle("Black", "Green", 10)
	circle3.printData()
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("\nFunction : playWithClasses")
	playWithClasses()

	println("\nFunction : playWithStudentGrades")
	playWithStudentGrades()

	println("\nFunction : playWithStudentAthlete")
	playWithStudentAthlete()

	println("\nFunction : playWithTypeCheck")
	playWithTypeCheck()

	println("\nFunction : playWithTypeCheckAgain")
	playWithTypeCheckAgain()

	println("\nFunction : playWithMammals")
	playWithMammals()

	println("\nFunction : playWithGeometries")
	playWithGeometries()

	println("\nFunction : playWithConstructors")
	playWithConstructors()

	println("\nFunction : playWithShape")
	playWithShape()

	println("\nFunction : playWithShapeAndCircle")
	playWithShapeAndCircle()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/
