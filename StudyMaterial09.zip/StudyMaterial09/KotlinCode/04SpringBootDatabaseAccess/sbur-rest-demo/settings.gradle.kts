rootProject.name = "sbur-rest-demo"
