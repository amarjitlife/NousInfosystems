
____________________________________________________________

DAY 01
____________________________________________________________

	Assignment 01: Reading, Coding and Experimentation
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming


	CASE STUDIES: KOTLIN ADOPTION
		https://www.youtube.com/watch?v=hXfGybzWaiA
		https://www.jetbrains.com/help/kotlin-multiplatform-dev/case-studies.html
		https://kotlinlang.org/lp/server-side/case-studies/
		https://android-developers.googleblog.com/2022/08/celebrating-5-years-of-kotlin-on-android.html

____________________________________________________________

DAY 02
____________________________________________________________

	Assignment 01: Reading, Coding and Experimentation
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming

		Reference Book: Java Complete Reference
			Java Collections : Two Chapters

____________________________________________________________

DAY 03
____________________________________________________________



____________________________________________________________

DAY 04
____________________________________________________________



____________________________________________________________

DAY 05
____________________________________________________________



____________________________________________________________

DAY 06
____________________________________________________________


____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________

