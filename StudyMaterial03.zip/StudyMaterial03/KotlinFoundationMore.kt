/* Commands
For Compiling Kotlin Code
kotlinc KotlinFoundationMore.kt -include-runtime -d more.jar

For Running JAR File
java -jar more.jar
*/

package learnKotlin

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// DESIGN PRACTICES
//		1. Create Always Type Safe Code
///				Type Safe Code: Respect Type Definition Like God
//		2. Always Prefer Exaustive Cases Rather Than else Branch
//		3. else Branch Should Be The Last Option
//		4. Avoid Exceptions in else Branch

// DESIGN PRACTICES
//		Exceptions Are Not That Exceptional Such That It Breaks Your Design


// DESIGN PRACTICES
//		Always Design Towards Deterministic Rather Than Non Deterministic

// Type Colour
//		Rmage = { RED, GREEN, BLUE, YELLOW }

enum class Colour {
	RED, GREEN, BLUE, YELLOW, ORANGE, UNKNOWN
}

// DESIGN 02
fun getColourString( colour: Colour ) : String {
	// when Is Type Safe An Expression
	//		Type Safe Respecting Type Definition Like God
	//		break Is Implicit
	return when( colour ) {
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE 	-> "Blue Colour"
		Colour.YELLOW 	-> "Yellow Colour"
		Colour.ORANGE 	-> "Orange Colour"
		Colour.UNKNOWN 	-> "Uknown Colour"		
	}
}

fun playWithColours() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )

	println( getColourString( Colour.RED ) )
	println( getColourString( Colour.GREEN ) )
	println( getColourString( Colour.BLUE ) )	
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

enum class Color(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255);

	fun rgb() = ( r * 256 + g) * 256 + b
}

fun getColorString( color: Color ) : String {
	// when Is A Type Safe Expression
	//		Type Safe Means Respecting Type Definition Like God
	return when( color ) {
		Color.RED 		-> "Red Colour"
		Color.GREEN 	-> "Green Colour"
		Color.BLUE 		-> "Blue Colour"
	}
}

fun playWithColors() {
	println( Color.RED )
	println( Color.GREEN )
	println( Color.BLUE )

	println( Color.RED.r )
	println( Color.RED.g )
	println( Color.RED.b )

	println( Color.RED.rgb() )
	println( Color.GREEN.rgb() )
	println( Color.BLUE.rgb() )

	println( getColorString( Color.RED ) )
	println( getColorString( Color.GREEN ) )
	println( getColorString( Color.BLUE ) )	
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("Function : playWithColours")
	playWithColours()

	println("Function : playWithColors")
	playWithColors()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/
