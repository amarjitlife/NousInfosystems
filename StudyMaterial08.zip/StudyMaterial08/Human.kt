
package learnKotlin

//_________________________________________________________
// DESIGN 01

// class Spiderman {
// 	fun fly() 		{ println("Fly Like Spiderman!") }
// 	fun saveWorld() { println("Save World Like Spiderman!") }
// }

// class Human {
// 	fun fly() 		{ println("Fly Like Human!") }
// 	fun saveWorld() { println("Save World Like Human!") }
// }

open class Spiderman {
	open fun fly() 		{ println("Fly Like Spiderman!") }
	open fun saveWorld() { println("Save World Like Spiderman!") }
}

open class Superman {
	open fun fly() 		{ println("Fly Like Superman!") }
	open fun saveWorld() { println("Save World Like Superman!") }
}

open class WonderWoman {
	open fun fly() 		{ println("Fly Like WonderWoman!") }
	open fun saveWorld() { println("Save World Like WonderWoman!") }
}

// DESIGN 01
//		Using Inheritance
// class Human : Spiderman() {
// class Human : Superman() {
class Human : WonderWoman() {	
	override fun fly() 			{ super.fly() }
	override fun saveWorld() 	{ super.saveWorld() }
}

fun playWithHuman() {
	val h = Human()
	h.fly()
	h.saveWorld()
}

//_________________________________________________________

interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman1: Superpower {
	override fun fly() 		{ println("Fly Like Spiderman1!") }
	override fun saveWorld() { println("Save World Like Spiderman1!") }
}

class Superman1: Superpower {
	override fun fly() 		{ println("Fly Like Superman1!") }
	override fun saveWorld() { println("Save World Like Superman1!") }
}

class WonderWoman1: Superpower {
	override fun fly() 		{ println("Fly Like WonderWoman1!") }
	override fun saveWorld() { println("Save World Like WonderWoman1!") }
}

//_________________________________________________________
// DESIGN 02
//		Using Composition
class HumanBetter {
	// var power = Spiderman1()
	var power = Superman1()
	fun fly() 		{ power?.fly() }
	fun saveWorld() { power?.saveWorld() }
}

fun playWithHumanBetter() {
	val h = HumanBetter()
	h.fly()
	h.saveWorld()
}

//_________________________________________________________
// DESIGN PRINCIPLE
//		Always Prefer Composition Over Inheritance

// DESIGN 03
//		Using Composition And Interfaces
// SOLID PRINCIPLES
//		Single Responsibility
//		Open-Close Principle
//			Classes Open Extension But Close For Modification
class HumanBest {
	var power: Superpower? = null 
	fun fly() 		{ power?.fly() }
	fun saveWorld() { power?.saveWorld() }
}

fun playWithHumanBest() {
	val h = HumanBest()
	h.power = Spiderman1()
	h.fly()
	h.saveWorld()

	h.power = Superman1()
	h.fly()
	h.saveWorld()

	h.power = WonderWoman1()
	h.fly()
	h.saveWorld()	
}

//_________________________________________________________

// error: supertypes cannot be nullable.
// class HumanAgain( val power: Superpower? ) : Superpower? by power 
class HumanAgain( var power: Superpower = Spiderman1() ) : Superpower by power 
// Compiler Will Generate Following Code For The Above Line
// {
// 	var power: Superpower = power
// 	fun fly() 		{ power?.fly() }
// 	fun saveWorld() { power?.saveWorld() }
// }

fun playWithHumanAgain() {
	val h = HumanAgain()
	h.fly()
	h.saveWorld()
	
	h.power = Superman1()
	h.fly()
	h.saveWorld()

	h.power = WonderWoman1()
	h.fly()
	h.saveWorld()
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("\nFunction : playWithHuman")
	playWithHuman()

	println("\nFunction : playWithHumanBetter")
	playWithHumanBetter()

	println("\nFunction : playWithHumanBest")
	playWithHumanBest()

	println("\nFunction : playWithHumanAgain")
	playWithHumanAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/

