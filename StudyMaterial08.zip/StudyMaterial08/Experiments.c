
#include<stdio.h>

void doSomething( int some ) {
	printf( "\nInside Function -> Some: %d", some );		
}

void playWithLocalVariables() {
	int some = 10;
	doSomething( some );

	if ( some == 10 ) {
		int some = 100;
		printf( "\nInside If -> Some: %d", some );		
	}
	printf( "\nOutside If -> Some: %d", some );		

	int i = 10;

	for ( int i = 0 ; i < 5 ; i++ ) {
		printf( "\n%d", i );					
	}
	
}
// Function : playWithLocalVariables
// Inside Function -> Some: 10
// Inside If -> Some: 100
// Outside If -> Some: 10
// 0
// 1
// 2
// 3
// 4

int main() {
	printf("\nFunction : playWithLocalVariables");
	playWithLocalVariables();

	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");	
	return 0;
}


