/* Commands
For Compiling Kotlin Code
kotlinc KotlinClasses.kt -include-runtime -d classes.jar

For Running JAR File
java -jar classes.jar
*/

package learnKotlin

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// In Kotlin By Default
//		Classes Are Final
//			Final Classes Can't Be Inherited
//		Class Memebers Are Also Final

// In Java By Default
//		Classes Are Open 
//			Open Classes Can Be Inherited
//		Class Memebers Are Also Open

// error: this type is final, so it cannot be extended.
open class View {
	val someData: Int = 99
	// Method Or Member Function
	// error: 'click' in 'View' is final and cannot be overridden.
	open fun click() = println("View: Clicked...")
}

// Button Class Inheriting From View Class
class Button : View() {
	override fun click() = println("Button: Clicked...")
	fun doMagic() = println("Button: Doing Magic...")
}

// Extension Functions
//		Are Like Member Functions i.e. You Can Call Like Member Functions
//		They Don't Participate In Overriding
fun View.showOff() 		= println("View: Doing ShowOff...")
fun Button.showOff() 	= println("Button: Doing ShowOff...")

fun playWithClasses() {
	// Created Instance/Object Of Class/Type View
	val someView = View() 
	println( someView.someData )
	someView.click()
	someView.showOff()

	val someButton = Button()
	println( someButton.someData )
	someButton.click()
	someButton.doMagic()
	someButton.showOff()

	val viewObject: View = Button()
	viewObject.click()
	viewObject.showOff()
	// Seeing Child Class Object w.r.t. Parent Class Perceptive
	// error: unresolved reference 'doMagic'.
	// viewObject.doMagic() 
	val bringBackButton = viewObject as Button
	bringBackButton.doMagic()
}
// Button: Clicked...
// Button: Doing Magic...
// Button: Clicked...
// Button: Doing Magic...

//_________________________________________________________
// INTERFACES WITH MEMBER FUNCTIONS

// In Kotlin/Java By Default
//		Interfaces Are Open
//			Open Interfaces Can Be Implemented By Concrete Class
//		Interface Abstract Memebers Are Also Open

interface Something {
	fun doSomething() = println("Something: Do Something")
}

interface Clickable {
	// warning: modifier 'open' is redundant for abstract interface members.
	// open fun click()
	fun click() // Abstract Member Function: Function With ONLY Signature
	// Default Methods Or Member Functions
	//		Member Functions With Default Implementation i.e. Body
	//		NOTE: It Should Be Used In Rarest Rare Cases
	//				Only FOR Scenarios Which Are REALLY COMMON TO Set Of Classes
	fun doFun() = println("Clickable: Do Fun!") // NOT A ABSTRACT Member Function
	// fun doSomething() = println("Clickable: Do Something")
}

interface Focusable {
	fun focus() // Abstract Member Function: Function With Signature
	// fun doSomething() = println("Focusable: Do Something")
}

// error: class 'Button1' is not abstract and does not implement abstract member 'click'.
class Button1 : Clickable, Focusable, Something {
	// error: class 'Button1' is not abstract and does not implement abstract member 'click'.
	override fun click() = println("Button1: click Called...")
	override fun focus() = println("Button1: focus Called...")
	override fun doFun() = println("Button1: Do Fun!")
	fun doMagic() = println("Button1: Doing Magic...")

	// error: class 'Button1' must override 'doSomething' 
	//		because it inherits multiple interface methods for it
	override fun doSomething() {
		// error: multiple supertypes available. 
		//		Please specify the intended supertype in angle brackets, e.g. 'super<Foo>'
		// super.doSomething()
		// Custom Logic To Resolve Ambiguity
		// super<Focusable>.doSomething()
		// super<Clickable>.doSomething()
		super.doSomething()
		println("Button1: Do Something!")
	}
}

fun playWithInterfaces() {
	val button = Button1()

	button.click()
	button.focus()
	button.doMagic()

	button.doFun()
	button.doSomething()
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// Color Type
//		Range = { RED(255, 0,0), GREEN(0, 255,0), BLUE(0,0,255) }
//		Operations = { rgb() }
enum class Color(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255);

	fun rgb() = ( r * 256 + g) * 256 + b
}

fun getColorString( color: Color ) : String {
	// when Is A Type Safe Expression
	//		Type Safe Means Respecting Type Definition Like God
	return when( color ) {
		Color.RED 		-> "Red Colour"
		Color.GREEN 	-> "Green Colour"
		Color.BLUE 		-> "Blue Colour"
	}
}

fun playWithEnums() {
	// error: cannot access 'constructor(r: Int, g: Int, b: Int): Color': 
	//		it is private in 'learnKotlin/Color'
	// val ORGANGE = Color(100, 100, 100)
}

fun playWithColors() {
	println( Color.RED )
	println( Color.GREEN )
	println( Color.BLUE )

	println( Color.RED.r )
	println( Color.RED.g )
	println( Color.RED.b )

	println( Color.RED.rgb() )
	println( Color.GREEN.rgb() )
	println( Color.BLUE.rgb() )

	println( getColorString( Color.RED ) )
	println( getColorString( Color.GREEN ) )
	println( getColorString( Color.BLUE ) )	
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// Type System: IS A Theorem
//		Types = { Expr, Num, Sum, Int }
interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

// Program: IS A Proof
// Kotlin Idiomatic Style Programming
fun evalulate( e: Expr ) : Int = when ( e ) {
	is Num -> e.value
	is Sum -> evalulate( e.left ) + evalulate( e.right )
	// error: 'when' expression must be exhaustive. Add an 'else' branch.
	else -> throw IllegalArgumentException("Unknown Expression!")
}

// Compiler: Theorem Prover!

fun playWithEvaluate() {
	// 100 + 200
	println( evalulate( Sum( Num(100), Num(200) ) ) )
	// (100 + 200) + 1000
	println( evalulate( Sum( Sum(Num(100), Num(200)), Num(1000) ) ))
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// Enum Classes
//		Enum Classes Can Have Fixed Number Of Choices ( Constants Objects )
//		Each Member(Choice) Have Same Common Constructor
// 		enum class Color(val r: Int, val g: Int, val b: Int) {
//				RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255);
//		}

// Sealed Class Can Be Used As Customisable Enum Classes
//		Sealed Classes Can Have Fixed Number Of Choices (Nested Classes)
//		Each Member Class(Choice) Have It's Own Custom Constructor

// Sealed classes and interfaces provide controlled 
// inheritance of your class hierarchies. 
// All direct subclasses of a sealed class are known at compile time. 
// 		No other subclasses may appear outside the module and package within 
// 		which the sealed class is defined. 

//	The same logic applies to sealed interfaces and their implementations: 
//	once a module with a sealed interface is compiled, 
//	no new implementations can be created.


// Sealed classes are best used for scenarios when:

// 1. Limited class inheritance is desired: 
//		You have a predefined, finite set of subclasses that 
//		extend a class, all of which are known at compile time.

// 2. Type-safe design is required: 
//		Safety and pattern matching are crucial in your project. 
//		Particularly for state management or handling complex 
//		conditional logic. 
//		For an example, check out Use sealed classes with when expressions.

// 3. Working with closed APIs: 
//		You want robust and maintainable public APIs 
//		for libraries that ensure that third-party clients 
//		use the APIs as intended.

//_________________________________________________________

/*
// EXAMPLE 01
// Create a sealed interface
sealed interface Error

// Create a sealed class that implements sealed interface Error
sealed class IOError(): Error

// Define subclasses that extend sealed class 'IOError'
class FileReadError(val file: File): IOError()
class DatabaseError(val source: DataSource): IOError()

// Create a singleton object implementing the 'Error' sealed interface
object RuntimeError : Error
*/

//_________________________________________________________
/*
// EXAMPLE 02
sealed class Error(val message: String) {
    class NetworkError : Error("Network failure")
    class DatabaseError : Error("Database cannot be reached")
    class UnknownError : Error("An unknown error has occurred")
}

fun main() {
    val errors = listOf(Error.NetworkError(), Error.DatabaseError(), Error.UnknownError())
    errors.forEach { println(it.message) }
}
*/

//_________________________________________________________
/*
// Beautiful Use Case Of Sealed Classes
sealed class UIState {
    data object Loading : UIState()
    data class Success(val data: String) : UIState()
    data class Error(val exception: Exception) : UIState()
}

fun updateUI(state: UIState) {
    when (state) {
        is UIState.Loading 	-> showLoadingIndicator()
        is UIState.Success 	-> showData(state.data)
        is UIState.Error 	-> showError(state.exception)
    }
}
*/
//_________________________________________________________
// Beautiful Use Case Of Sealed Classes
/*
sealed class Payment {
    data class CreditCard(val number: String, val expiryDate: String) : Payment()
    data class PayPal(val email: String) : Payment()
    data object Cash : Payment()
}

fun processPayment(payment: Payment) {
    when (payment) {
        is Payment.CreditCard 	-> processCreditCardPayment(payment.number, payment.expiryDate)
        is Payment.PayPal 		-> processPayPalPayment(payment.email)
        is Payment.Cash 		-> processCashPayment()
    }
}
*/
//_________________________________________________________

// open class Expression {
sealed class Expression {
	class Num(val value: Int) : Expression()
	class Sum(val left: Expression, val right: Expression) : Expression()
}

// sealed class Expression {
// }

// class Number(val value: Int) : Expression()
// class Summation(val left: Expression, val right: Expression) : Expression()

// Kotlin Idiomatic Style Programming
fun evalulateAgain( e: Expression ) : Int = when ( e ) {
	// Pattern Matching
	is Expression.Num -> e.value
	// error: 'when' expression must be exhaustive. Add the 'is Sum' branch or an 'else' branch.
	is Expression.Sum -> evalulateAgain( e.left ) + evalulateAgain( e.right )
	// error: 'when' expression must be exhaustive. Add an 'else' branch.
	// else -> throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEvaluateAgain() {
	// 100 + 200
	println( evalulateAgain( Expression.Sum( 
									Expression.Num(100), 
									Expression.Num(200) ) ) )
	// (100 + 200) + 1000
	println( evalulateAgain( Expression.Sum( 
								Expression.Sum(
										Expression.Num(100), 
										Expression.Num(200)), 
								Expression.Num(1000) ) ))
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// BEST PRACTICES
//		Always Prefer Constructor With Default Arguments
//		Rather Than Constructor Overloading

// Polymorphic Constructor
// 		Mechanims: Using Constructor With Default Arugments
class User( val nickName: String, val isSubscribed: Boolean = false )

fun playWithUser() {
	//			 Invoking Constructor With 1 Argument
	val gabbar = User( nickName = "Gabbar" )
	println( gabbar.nickName )
	println( gabbar.isSubscribed )

	//			 Invoking Constructor With 2 Arguments
	val basanti = User( nickName = "Basanti", isSubscribed = true )	
	println( basanti.nickName )
	println( basanti.isSubscribed )
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// INTERFACES WITH MEMBER PROPERTIES

// Interfaces Are Pure Abstract Classes
interface SomeUser {
	val nickname: String 
}
// Concrete Classes
// error: 'nickname' hides member of supertype 'SomeUser' 
//		and needs an 'override' modifier.
// class PrivateUser( val nickname: String ) : SomeUser
class PrivateUser( override val nickname: String ) : SomeUser

class SubscribingUser( val email: String ) : SomeUser {
	// Overriding Means Overriding Getter/Setter 
	// It's Not Overriding Member Variable/Field Associated With Member Property
	override val nickname : String
		get() = email.substringBefore('@')
}

class FacebookUser( val accountID: Int ) : SomeUser {
	override val nickname : String
	 	get() = "FB::$accountID"
}

fun playWithInterfaceProperties() {
	// val someUser = SomeUser()

	val gabbar = PrivateUser( nickname = "Gabbar Singh" )
	println( gabbar.nickname )

	val basanti = SubscribingUser( email = "basanti@shole.com" )
	println( basanti.nickname )

	val veeru = FacebookUser( 999 )
	println( veeru.nickname )
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// INTERFACES WITH MEMBER PROPERTIES
//		Having Getters/Setters Defined At Interface
//			Default Implementation/Body

interface SomeUserAgain {
	val email: String
		get() {
			println("SomeUserAgain: email Getter Called")
			return "unknown@nousinfosystems.com"
		}

	val nickname: String // With Custom Getter
		get() = email.substringBefore('@') // getEmail().substringBefore('@')

	var name: String // With Custom Getter/Setter
		get(){ 
			println("SomeUserAgain: name Getter Called")
			return "Unknown"
		} 

		set( value ) {
			println("SomeUserAgain: name Setter Called With Value: $value")
		}
}

class Employee: SomeUserAgain {
	override val email: String // = "employee@nousinforsystems.com"
		get() { // Overriding Getter
			println("Employee: email Getter Called")
			return "employee@nousinfosystems.com"
		} 
}

fun playWithEmployee() {
	val gabbar = Employee()
	println( gabbar.email )
	println( gabbar.nickname ) // gabbar.getNickName()
	println( gabbar.name )
	gabbar.name = "Gabbar Singh"
	println( gabbar.name )	
}

// Function : playWithEmployee
// Employee: email Getter Called
// employee

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// Properties Member Variable
//		Member Variable Is Called Field In Kotlin
//		For Each Property There Will Be One field Variable

class UserClass( var name: String = "Uknown" ) {
	var address: String = "Unspecified"
		get() {
			// Member Variable/Field Corresponding Member Property
			println("UserClass: address Getter Called Value At Field: $field")
			return field 
		}

		set( value: String ) {
			println("UserClass: address Setter Called Before Setting: $field")
			field = value
			println("UserClass: address Setter Called After Setting: $field")
		}
}


fun playWithMemberField() {
	val gabbar = UserClass( name = "Gabbar Singh" )

	println( gabbar.name )
	println( gabbar.address )
	gabbar.address = "Ramgarh"
	println( gabbar.address )

	val basanti = UserClass()
	println( basanti.name )
	println( basanti.address )
	basanti.name = "Basanti"
	basanti.address = "Ramgarh"
	println( basanti.name )	
	println( basanti.address )
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

class UserClassAgain( ) {
	var name: String = "Unknown"
		get() { 
			return field 
		}

		set( value: String ) {
			field = "Ye Dil Maange More!!!"
		}

	var address: String = "Unspecified"
		get() {
			// Member Variable/Field Corresponding Member Property
			println("UserClass: address Getter Called Value At Field: $field")
			return field 
		}

		set( value: String ) {
			println("UserClass: address Setter Called Before Setting: $field")
			field = value
			println("UserClass: address Setter Called After Setting: $field")
		}
}

fun playWithMemberFieldAgain() {
	val gabbar = UserClassAgain()

	println( gabbar.name )
	println( gabbar.address )
	gabbar.address = "Ramgarh"
	println( gabbar.address )

	val basanti = UserClassAgain()
	println( basanti.name )
	println( basanti.address )
	basanti.name = "Basanti"
	basanti.address = "Ramgarh"
	println( basanti.name )	
	println( basanti.address )
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// Making Getter/Setter Private
class LengthCounter {
	var counter : Int = 0
		private set // 		Private Setter

	fun addWord( word: String ) {
		counter = counter + word.length
	}
}

fun playWithLengthCOunter() {
	val lengthCounter = LengthCounter()
	println( lengthCounter.counter )
	lengthCounter.addWord("Hi")
	println( lengthCounter.counter )
	lengthCounter.addWord("Good")
	println( lengthCounter.counter )	
	// lengthCounter.count = 100
}

//_________________________________________________________

class Client1(val name: String, val postalCode: Int ) {
	override fun toString() : String {
		return "Client1(name=$name, postalCode=$postalCode)"
	}
}

fun playWithClient1() {
	val gabbar = Client1( "Gabbar Singh", 420420 )

	println( gabbar.name )
	println( gabbar.postalCode )

	println( gabbar )
}


//_________________________________________________________

class Client2(val name: String, val postalCode: Int ) {
	override fun toString() : String {
		return "Client2(name=$name, postalCode=$postalCode)"
	}

	// To Overload Equality Operator ==
	//		Override equals Methods
	override fun equals( other: Any? ) : Boolean {
		if ( other == null || other !is Client2 ) return false
		return other.name == name && other.postalCode == postalCode
	}
}

fun playWithClient2() {
	val gabbar1 = Client2( "Gabbar Singh", 420420 )
	val gabbar2 = Client2( "Gabbar Singh", 420420 )

	println( gabbar1 )
	println( gabbar2 )
	println( gabbar1 == gabbar2 ) // gabbar1.equals( gabbar2 )
}

//_________________________________________________________
// DATA CLASSES
//		Compiler Will Generate Following Functions
//			1. toString Method Code Generated
//				With All The Properties
//			2. equals Method Code Generated
//				By Comparing All The Properties
//			3. hashCode Method Code Generated
//				Hash Code Calcuated Based On All Immutable Properties
//			4. copy Method Code Will Generated

data class Client3(val name: String, val postalCode: Int ) 
// {
// 	override fun toString() : String {
// 		return "Client1(name=$name, postalCode=$postalCode)"
// 	}

// 	// To Overload Equality Operator ==
// 	//		Override equals Methods
// 	override fun equals( other: Any? ) : Boolean {
// 		if ( other == null || other !is Client2 ) return false
// 		return other.name == name && other.postalCode == postalCode
// 	}
// }

fun playWithClient3() {
	val gabbar1 = Client3( "Gabbar Singh", 420420 )
	val gabbar2 = Client3( "Gabbar Singh", 420420 )

	println( gabbar1 )
	println( gabbar2 )
	println( gabbar1 == gabbar2 ) // gabbar1.equals( gabbar2 )
}

//_________________________________________________________

// DATA CLASSES
//		Compiler Will Generate Following Functions
//			1. toString Method Code NOT Generated
//			2. equals Method Code Generated
//				By Comparing All The Properties
//			3. hashCode Method Code Generated
//				Hash Code Calcuated Based On All Immutable Properties
//			4. copy Method Code Will Generated


data class Client4(val name: String, val postalCode: Int ) {
	override fun toString() : String {
		println("Function: toString Called...")
		return "Client4(name=$name, postalCode=$postalCode)"
	}

// 	// To Overload Equality Operator ==
// 	//		Override equals Methods
// 	override fun equals( other: Any? ) : Boolean {
// 		if ( other == null || other !is Client2 ) return false
// 		return other.name == name && other.postalCode == postalCode
// 	}
}

fun playWithClient4() {
	val gabbar1 = Client4( "Gabbar Singh", 420420 )
	val gabbar2 = Client4( "Gabbar Singh", 420420 )

	println( gabbar1 )
	println( gabbar2 )
	println( gabbar1 == gabbar2 ) // gabbar1.equals( gabbar2 )
}

//_________________________________________________________

// object Classes
//		Singleton Classes In Kotlin
//			Can Have Only One Instance
//			Instance Name Is Same As Class Name
object India {
	fun name() : String {
		return "Hindustan!"
	}
}

fun playWithIndia() {
	//
	val data = India.name()
	println( data )
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("\nFunction : playWithClasses")
	playWithClasses()

	println("\nFunction : playWithInterfaces")
	playWithInterfaces()

	println("\nFunction : playWithColors")
	playWithColors()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithEvaluateAgain")
	playWithEvaluateAgain()

	println("\nFunction : playWithUser")
	playWithUser()

	println("\nFunction : playWithInterfaceProperties")
	playWithInterfaceProperties()

	println("\nFunction : playWithEmployee")
	playWithEmployee()

	println("\nFunction : playWithMemberField")
	playWithMemberField()

	println("\nFunction : playWithMemberFieldAgain")
	playWithMemberFieldAgain()

	println("\nFunction : playWithLengthCOunter")
	playWithLengthCOunter()

	println("\nFunction : playWithClient1")
	playWithClient1()

	println("\nFunction : playWithClient2")
	playWithClient2()

	println("\nFunction : playWithClient3")
	playWithClient3()

	println("\nFunction : playWithClient4")
	playWithClient4()

	println("\nFunction : playWithIndia")
	playWithIndia()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/
