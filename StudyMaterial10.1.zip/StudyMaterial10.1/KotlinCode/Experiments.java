
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

class SingletonClass {
	private static SingletonClass instance = null ;
	public String data;

	private SingletonClass() { data = "Created!"; }

	public static SingletonClass getInstance() {
		if ( instance == null ) 
			instance = new SingletonClass();

		return instance;
	}
}


/**
*
* A simple Java Program to demonstrate how to use map and filter method Java 8.
* In this program, we'll convert a list of String into a list of Integer and
* then filter all even numbers.
*/

class MapFilterDemo {
  
	 public static void playWithMapFilter() {
	    List<String> numbers = Arrays.asList("1", "2", "3", "4", "5", "6");
	    System.out.println("original list: " + numbers);

	    List<Integer> even = numbers.stream()
	                                .map( s -> Integer.valueOf(s) )
	                                .filter( number -> number % 2 == 0 )
	                                .collect(Collectors.toList());
	  
	    System.out.println("processed list, only even numbers: " + even);
	}
}

// Function : playWithMapFilter
// original list: [1, 2, 3, 4, 5, 6]
// processed list, only even numbers: [2, 4, 6]

class Experiments {
	public static void doSomething( int some ) {
		{
			// int some = 99;
			System.out.println( "Inside Function -> Some: " + some );		
		}
	}

	public static void playWithLocalVariables() {
		int some = 10;
		doSomething( some );

		if ( some == 10 ) {
			// int some = 100;
			System.out.println( "Inside If -> Some: " + some );		
		}
		System.out.println( "Outside If -> Some: " + some );				
		
		{
			int i = 10;
		}

		for ( int i = 0 ; i < 10 ; i++ ) {
			System.out.println( i );					
		}
	}

	public static void playWithSingleton() {
		SingletonClass first = SingletonClass.getInstance();

		System.out.println( first.data );
		first.data = "Assigned New Data";
		System.out.println( first.data );
	
		SingletonClass second = SingletonClass.getInstance();
		System.out.println( second.data );			
	}

	public static void main(String[] args) {
		System.out.println("Welcome Experiments!!!");

		System.out.println("\nFunction : playWithLocalVariables");
		playWithLocalVariables();

		System.out.println("\nFunction : playWithSingleton");
		playWithSingleton();

		System.out.println("\nFunction : playWithMapFilter");
		MapFilterDemo.playWithMapFilter();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

