
package learnKotlin

//_________________________________________________________

data class Email(val from: String, val to: String, val title: String )

fun loadEmails( name: String ) : List<Email> {
	println("Loading Emails...")

	// Generally Emails Data From Database/Email Server
	val emails = listOf(
		Email("gabbar@gmail.com", "Samba@gmail.com", "Kitne Aaadmi Thee"),
		Email("gabbar@gmail.com", "Kalia@gmail.com", "Kitne Aaadmi Thee"),
		Email("gabbar@gmail.com", "thakur@gmail.com", "Ye Haat Mujhe De De Thakurr"),
		Email("veeru@gmail.com", "gabbar@gmail.com", "En Kuthoon Ke Saane Maat Nachna"),
	)

	return  emails
}

data class PersonLazy1( val name: String ) {
	private var _emails: List<Email>? = null

	val emails: List<Email>
		get() {
			// Lazy Loading Pattern
			if ( _emails == null ) { _emails = loadEmails( name ) }
			return _emails!!
		}
}

data class PersonLazy2( val name: String ) {
	val emails by lazy { loadEmails( name ) }
	// Compiler Will Generate Following Code For This Class
	// private var _emails: List<Email>? = null
	// val emails: List<Email>
		// get() {
	// 	// Lazy Loading Pattern
		// 	if ( _emails == null ) { _emails = loadEmails( name ) }
		// 	return _emails!!
		// }
}

fun playWithPerson() {
	val gabbar1 = PersonLazy1( "Gabbar Singh")
	println( gabbar1 )
	println( gabbar1.emails )

	val gabbar2 = PersonLazy2( "Gabbar Singh")
	println( gabbar2 )
	println( gabbar2.emails )
}


// Function : playWithPerson
// PersonLazy1(name=Gabbar Singh)

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("\nFunction : playWithPerson")
	playWithPerson()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/

