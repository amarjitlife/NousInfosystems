
package learnKotlin

import kotlinx.coroutins.*

/*
//_________________________________________________________
// What Is Concurrency?
// What Is Parallelism?

// Large Wall To Paint 

// DESIGN: CONCURRENT
// 3 Small Wall Portions To Paint 
//		Tasks Are Independent
Coroutine 01 			Coroutine 02 			Coroutine 03
Task 01  				Task 02 				Task 03
Bucket 01 				Bucket 02 				Bucket 03
Brush 01  				Brush 02 				Brush 03
//________________________________________________________
// EXECUTION: PARALLEL AND/OR SEQUENTIAL
//		Workers Count >= Task Count :: 100 % PARALLEL
//		01 Worker < Workers Count < Task Count  :: Some Part Parallel Some Will Be Sequential
//		Workers Count = 01 :: 100% Seqential
//		Shared Resources Across Task Can Result Into Sequential

Worker 01				Worker 02 				Worker 03				Woker 04
Tom						Alice 					Bob						Gabbar 

// Wokers : Thread, Process, Processor, Cores In Processor
*/

//_________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking { // Creates First Coroutine
	
	launch { // Creates Second Coroutine
		delay( 1000L )
		println("Hello!!!")
	}
	println("World!!!")
}

//_________________________________________________________

// A coroutine is an instance of a suspendable computation. 
// It is conceptually similar to a thread, in the sense that it takes 
// a block of code to run that works concurrently with the rest of the code. 
// However, a coroutine is not bound to any particular thread. 

// It may suspend its execution in one thread and resume in another one.


// launch is a coroutine builder. 
// It launches a new coroutine concurrently with the rest of the code, 
// which continues to work independently. 

// delay is a special suspending function. 
// It suspends the coroutine for a specific time. 
// Suspending a coroutine does not block the underlying thread, 
// but allows other coroutines to run and use the underlying thread 
// for their code.

// runBlocking is also a coroutine builder 
// that bridges the non-coroutine world of a regular fun main() and 
// the code with coroutines inside of runBlocking { ... } curly braces. 

// The name of runBlocking means that the thread that runs it 
// (in this case — the main thread) gets blocked for the duration of the call, 
// until all the coroutines inside runBlocking { ... } complete their execution. 
// You will often see runBlocking used like that at the very top-level 
// of the application  and quite rarely inside the real code, as 
// threads are expensive resources and blocking  them is inefficient 
// and is often not desired.

// Structured concurrency
// Coroutines follow a principle of structured concurrency 
// which means that new coroutines can only be launched in a specific 
// CoroutineScope which delimits the lifetime of the coroutine.

// An outer scope cannot complete until all its children coroutines complete. 
// Structured concurrency also ensures that any errors in the code are 
// properly reported and are never lost.


//_________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking { // Creates First Coroutine Inside CRS 01
	
	launch { // Creates Second Coroutine Inside CRS 03
		doHello()
	}
	println("World!!!")
}

suspend fun doHello() {
	delay( 1000L )
	println("Hello!!!")
}

// This is your first suspending function. 
// Suspending functions can be used inside coroutines just like regular functions, 
// but their additional feature is that they can, in turn, use other suspending 
// functions (like delay in this example) to suspend execution of a coroutine.


//_________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking { // this: CoroutineScope
    launch { 
    	doWorld() 
        hello()
    }
    println("Hello")
}

// this is your first suspending function
suspend fun doWorld() {
    delay(1000L)
    println("World!")
}

fun hello() {
    println("Hhhhhhh")
}

//_________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking { // Creates A Coroutine CRS 01
	doWorld()
	println("Done")
}

suspend fun doWorld() = coroutineScope { // Creating 02 Couroutines in CRS 02 doWord
	launch {
		delay( 2000L )
		println("World 02")
	}

	launch {
		delay( 1000L )
		println("World 01")
	}

	println("Hello")
}

//_________________________________________________________

// Scope builder
// In addition to the coroutine scope provided by different builders, 
// it is possible to declare your own scope using the coroutineScope builder. 
// It creates a coroutine scope and does not complete until all launched 
// children complete.

// runBlocking and coroutineScope builders may look similar because they 
// both wait for their body and all its children to complete. 

// The main difference is that the runBlocking method blocks the current 
// thread for waiting, while coroutineScope just suspends, releasing 
// the underlying thread for other usages. Because of that difference, 
// runBlocking is a regular function and coroutineScope is a 
// suspending function.

//_________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking { // Creates A Coroutine CRS 01
	val job = launch {
		delay( 1000L )
		println("World!")
	}

	println("Hello")
	job.join()
	println("Done")
}

//_________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking { // Creates A Coroutine CRS 01
	
	repeat( 5_000 ) {
		launch {
			println(".!")
		}
	}

	println("Hello")
}


//_________________________________________________________

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking { // Creates A Coroutine CRS 01
	
	val channel = Channel<Int>()

	launch {
		for( x in 1..5 ) channel.send( x * x )
	}

	repeat( 5 ) { println( channel.receive() ) }
	println("Hello")
}


//_________________________________________________________

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking { // Creates A Coroutine CRS 01
	
	val channel = Channel<Int>()

	launch {
		for( x in 1..5 ) channel.send( x * x )
        channel.close()
	}

	//repeat( 5 ) { println( channel.receive() ) }
	for ( square in channel ) println( square )
    println("Hello")
}

//_________________________________________________________

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun CoroutineScope.produceSquares() : ReceiveChannel<Int> = produce {
	for( x in 1..5 ) send( x * x )
}

fun main() = runBlocking { // Creates A Coroutine CRS 01
	val squares = produceSquares()	

	squares.consumeEach {
		println( it )
	}

  	println("Done!")
}


//_________________________________________________________


import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking {

    val numbers = produceNumbers() // produces integers from 1 and on
    val squares = square(numbers) // squares integers
    repeat(5) {
        println(squares.receive()) // print first five
    }
    println("Done!") // we are done
    coroutineContext.cancelChildren() // cancel children coroutines

}

// Pipelines﻿
// A pipeline is a pattern where one coroutine is producing, 
//  	possibly infinite, stream of values:
fun CoroutineScope.produceNumbers() = produce<Int> {
    var x = 1
    while (true) send(x++) // infinite stream of integers starting from 1
}

fun CoroutineScope.square(numbers: ReceiveChannel<Int>): ReceiveChannel<Int> = produce {
    for (x in numbers) send(x * x)
}


//_________________________________________________________


import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking<Unit> {

    val channel = Channel<Int>(4) // create buffered channel
    val sender = launch { // launch sender coroutine
        repeat(10) {
            println("Sending $it") // print before sending each element
            channel.send(it) // will suspend when buffer is full
        }
    }
    // don't receive anything... just wait....
    delay(1000)
    sender.cancel() // cancel sender coroutine
    
}

//_________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking {

    val startTime = System.currentTimeMillis()
    
    val job = launch( Dispatchers.Default) {
        var nextPrintTime = startTime
        var i = 0

        while (isActive) { // cancellable computation loop
            // print a message twice a second
            if (System.currentTimeMillis() >= nextPrintTime) {
                println("job: I'm sleeping ${i++} ...")
                nextPrintTime += 500L
            }
        }
    }

    delay(1300L) // delay a bit
    println("main: I'm tired of waiting!")
    job.cancelAndJoin() // cancels the job and waits for its completion
    println("main: Now I can quit.")
    
}

//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/


