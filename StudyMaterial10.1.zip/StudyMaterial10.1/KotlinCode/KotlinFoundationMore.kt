/* Commands
For Compiling Kotlin Code
kotlinc KotlinFoundationMore.kt -include-runtime -d more.jar

For Running JAR File
java -jar more.jar
*/

package learnKotlin

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// DESIGN PRACTICES
//		1. Create Always Type Safe Code
///				Type Safe Code: Respect Type Definition Like God
//		2. Always Prefer Exaustive Cases Rather Than else Branch
//		3. else Branch Should Be The Last Option
//		4. Avoid Exceptions in else Branch

// DESIGN PRACTICES
//		Exceptions Are Not That Exceptional Such That It Breaks Your Design


// DESIGN PRACTICES
//		Always Design Towards Deterministic Rather Than Non Deterministic

// Type Colour
//		Rmage = { RED, GREEN, BLUE, YELLOW }

enum class Colour {
	RED, GREEN, BLUE, YELLOW, ORANGE, UNKNOWN
}

// DESIGN 02
fun getColourString( colour: Colour ) : String {
	// when Is Type Safe An Expression
	//		Type Safe Respecting Type Definition Like God
	//		break Is Implicit
	return when( colour ) {
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE 	-> "Blue Colour"
		Colour.YELLOW 	-> "Yellow Colour"
		Colour.ORANGE 	-> "Orange Colour"
		Colour.UNKNOWN 	-> "Uknown Colour"		
	}
}

fun playWithColours() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )

	println( getColourString( Colour.RED ) )
	println( getColourString( Colour.GREEN ) )
	println( getColourString( Colour.BLUE ) )	
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// Color Type
//		Range = { RED(255, 0,0), GREEN(0, 255,0), BLUE(0,0,255) }
//		Operations = { rgb() }
enum class Color(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255);

	fun rgb() = ( r * 256 + g) * 256 + b
}

fun getColorString( color: Color ) : String {
	// when Is A Type Safe Expression
	//		Type Safe Means Respecting Type Definition Like God
	return when( color ) {
		Color.RED 		-> "Red Colour"
		Color.GREEN 	-> "Green Colour"
		Color.BLUE 		-> "Blue Colour"
	}
}

fun playWithColors() {
	println( Color.RED )
	println( Color.GREEN )
	println( Color.BLUE )

	println( Color.RED.r )
	println( Color.RED.g )
	println( Color.RED.b )

	println( Color.RED.rgb() )
	println( Color.GREEN.rgb() )
	println( Color.BLUE.rgb() )

	println( getColorString( Color.RED ) )
	println( getColorString( Color.GREEN ) )
	println( getColorString( Color.BLUE ) )	
}

//_________________________________________________________

//_________________________________________________________

interface Expr
// Class Num Implementing Expr Interface
//							vvvv
class Num(val value: Int) : Expr
// Class Num Implementing Expr Interface 	 vvvv
//		Constructor Takes 2 Arguments Of Expr Type i.e. Interface
//		Polymorphic Constructor:
//				Mechanism: Using Interface Type Argument
//					vvvv             vvvv
class Sum(val left: Expr, val right: Expr) : Expr

fun eval( e: Expr ) : Int {
	// What Is The Type Of e Here? : Expr
	if ( e is Num ) { // Smart Type Casting
	//	Checking Type Of e Is Num Or Not?
	//		Equivalent In Java :: e instanceOf Num 
	//		If It's TRUE
	//		Than It Type Casts e To Num Type
	//		Equivalent In Java Num _e = (Num) e
		// What Is The Type Of e Here?: Num 
		return e.value
		// Equivalent In Java return _e.value
		// e.value
	}

	// What Is The Type Of e Here? : Expr	
// :153:13: error: unresolved reference 'value'.
 	// println( e.value )
	if ( e is Sum ) {
		// val e = (Sum) e
		// What Is The Type Of e Here?: Sum		
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEval() {
	// 100 + 200
	println( eval( Sum( Num(100), Num(200) ) ) )

	// (100 + 200) + 1000
	println( eval( Sum( Sum(Num(100), Num(200)), Num(1000) ) ))
}

//_________________________________________________________
//_________________________________________________________

fun max( a: Int, b: Int ) : Int {
	return if ( a > b ) a else b
}

fun maxAgain( a: Int, b: Int ) : Int {
	//	if-else Is An Expression
	//	It's Value Is Block Value Either if Block OR else Block
	//		Value Of Block Is Last Expression Evaluated In Block
	return if ( a > b ) {
				a 
				a + 10 
			} else {
				b
				b - 10
			}
}

fun maximum( a: Int, b: Int )  = if ( a > b ) a else b

fun playWithMax() {
	var result: Int
	result = max( 20, 10 )
	println("Result: $result")
	result = maxAgain( 20, 10 )
	println("Result: $result")

	result = maximum( 20, 10 )
	println("Result: $result")
}
// Function : playWithMax
// Result: 20
// Result: 30
// Result: 20
//_________________________________________________________

// interface Expr
// class Num(val value: Int) : Expr
// class Sum(val left: Expr, val right: Expr) : Expr

// Kotlin Idiomatic Style Programming
fun evalIf( e: Expr ) : Int = if ( e is Num ) {
		e.value
	} else if ( e is Sum ) {
		evalIf( e.left ) + evalIf( e.right )
	} else {
		throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEvalIf() {
	// 100 + 200
	println( evalIf( Sum( Num(100), Num(200) ) ) )
	// (100 + 200) + 1000
	println( evalIf( Sum( Sum(Num(100), Num(200)), Num(1000) ) ))
}

//_________________________________________________________
// interface Expr
// class Num(val value: Int) : Expr
// class Sum(val left: Expr, val right: Expr) : Expr

// Kotlin Idiomatic Style Programming
fun evalulate( e: Expr ) : Int = when ( e ) {
	is Num -> e.value
	is Sum -> evalulate( e.left ) + evalulate( e.right )
	else -> throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEvaluate() {
	// 100 + 200
	println( evalulate( Sum( Num(100), Num(200) ) ) )
	// (100 + 200) + 1000
	println( evalulate( Sum( Sum(Num(100), Num(200)), Num(1000) ) ))
}

//_________________________________________________________
// HOME WORK: THINKING AND EXPERIMENATION EXCERCISE!!!
//_________________________________________________________

/*
// Kotlin Idiomatic Style Programming
fun evalulate1( e: Expr ) = when ( e ) {
	is Num -> e.value
	 // error: type checking has run into a recursive problem. 
	//		Easiest workaround: 
	//			Specify the types of your declarations explicitly.
	is Sum -> evalulate1( e.left ) + evalulate1( e.right )
	else -> throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEvaluate1() {
	// 100 + 200
	println( evalulate1( Sum( Num(100), Num(200) ) ) )
	// (100 + 200) + 1000
	println( evalulate1( Sum( Sum(Num(100), Num(200)), Num(1000) ) ))
}
*/

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

// Polymorphic Function
//		Mechanism: Function Overloading
fun printData( data: Num ) {
	println( data.value )
}

// Polymorphic Function
//		Mechanism: Function Overloading
fun printData( data: Sum ) {
	println( "Left : ${data.left} Right: ${data.right}" )
}

// Polymorphic Function
//		Mechanism: Using Interface Type Argument
fun printData( data: Expr ) {
	if ( data is Num ) {
		println( data.value )
	}

	if ( data is Sum ) {
		println( "Left : ${data.left} Right: ${data.right}" )
	}
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("\nFunction : playWithColours")
	playWithColours()

	println("\nFunction : playWithColors")
	playWithColors()

	println("\nFunction : playWithEval")
	playWithEval()

	println("\nFunction : playWithMax")
	playWithMax()

	println("\nFunction : playWithEvalIf")
	playWithEvalIf()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	// println("\nFunction : playWithEvaluate1")
	// playWithEvaluate1()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/
