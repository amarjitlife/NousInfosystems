
package learnKotlin

import java.math.BigDecimal

//_________________________________________________________

data class Point( val x: Int, val y: Int ) {
	// Overloaded + Operator For Point Type
	operator fun plus( other: Point ) : Point {
		println("plus Operator Called..")
		val xx = this.x + other.x
		val yy = this.y + other.y
		return Point(xx, yy)
	}

	override fun equals( other: Any? ) : Boolean {
		println("equals Operator Called..")
		if ( other == null || other !is Point ) return false
		return other.x == x && other.y == y
	}
}

// Using Extensions To Add Operator To Point Type
operator fun Point.times( scalar : Int ) : Point {
	println("times Operator Called..")	
	return Point( x * scalar, y * scalar )
}

operator fun Point.unaryMinus() : Point {
	println("unaryMinus Operator Called..")	
	return Point( -x, - y )
}

fun playWithPoints() {
	val point1 = Point(10, 20)
	val point11 = Point(10, 20)
	val point2 = Point(20, 30)

	val xx = point1.x + point2.x
	val yy = point1.y + point2.y
	val point3 = Point(xx, yy)

	println( point1 )
	println( point2 )
	println( point3 )

	val point4 = point1 + point2 // point1.plus( point2 )
	println( point4 )

	println( point1 == point2  )  // point1.equals( point2 )
	println( point1 == point11  ) // point1.equals( point11 )
	println( point1 != point2  )  // point1.equals( point2 )

	println( point1 * 10 ) // point1.times( 10 )
	println( point1 * 2 ) // point1.times( 10 )	

	println( -point1 ) //point1.unaryMinus()
	println( -point2 ) //point1.unaryMinus()
}

//_________________________________________________________

// import java.math.BigDecimal

operator fun BigDecimal.inc() = this + BigDecimal.ONE 

fun playWithUniaryIncrement() {
	var bigZero = BigDecimal.ZERO

	println( bigZero )
	println( ++bigZero ) // bigZero.inc()	
}

//_________________________________________________________

class Person( val firstName: String, val lastName: String ) : Comparable<Person> {
	override fun compareTo( other: Person ) : Int {
		return compareValuesBy( this, other, Person::lastName, Person::firstName)
	}
}

fun playWithPersonsComparision() {
	val alice = Person("Alice", "Smith")
	val aliceAgain = Person("Alice", "Carol")

	val gabbar = Person("Gabbar", "Singh")

	println( alice < aliceAgain ) // alice.compareTo( aliceAgain )
	println( alice > gabbar )
}

//_________________________________________________________

operator fun Point.get(index: Int ) : Int {
	return when( index ) {
		0 -> x
		1 -> y
		else -> throw IndexOutOfBoundsException("Index Out Of Bound")
	}
}

fun playWithPointsAgain() {
	val point = Point(11, 22 )

	println( point[0] ) // point.get( 0 )
	println( point[1] )	// point.get( 1 )
}

//_________________________________________________________

data class MutablePoint( var x: Int, var y: Int )

operator fun MutablePoint.get(index: Int ) : Int {
	return when( index ) {
		0 -> x
		1 -> y
		else -> throw IndexOutOfBoundsException("Index Out Of Bound")
	}
}

operator fun MutablePoint.set( index: Int, value: Int ) {
	when( index ) {
		0 -> x = value
		1 -> y = value
		else -> throw IndexOutOfBoundsException("Index Out Of Bound")
	}
}

fun playWithMutablePoint() {
	val point = MutablePoint(11, 22 )

	println( point[0] ) // point.get( 0 )
	println( point[1] )	// point.get( 1 )

	point[0] = 88 // point.set(0, 88)
	point[1] = 99 // point.set(1, 99)

	println( point[0] ) // point.get( 0 )
	println( point[1] )	// point.get( 1 )
}


//_________________________________________________________

data class Rectangle( val upperLeft: Point, val lowerRight: Point ) 

operator fun Rectangle.contains( point: Point ) : Boolean {
	return point.x in upperLeft.x until lowerRight.x &&
		   point.y in upperLeft.y until lowerRight.y
}

fun playWithOperatorIn( ) {
	val point1 = Point( 10, 20 )
	val point2 = Point( 100, 200 )

	val point = Point( 50, 50 )

	val rectangle = Rectangle( point1, point2 )
	println( point in rectangle ) // rectangle.contains( point )
}

//_________________________________________________________

class NumberAgain(private val target: Int) {
    infix fun isEqualTo(other: Int): Boolean {
        return other == target
    }

    infix fun add( other: Int ) : Int {
    	return other + target
    }

    infix fun substract( other: Int ) : Int {
    	return other + target
    }    
}

fun playWithInfixFunctions() {
	val number = NumberAgain(5)

	// Infix Notation
	//		Binary Operator Comes In Between Two Operands 
	//		a + b  Here a, b Are Operands And + Operator

	// Infix Notation
	//		Binary Operator Comes In Between Two Operands 
	//		number and 5 Are Operands
	//	    isEqualTo Is Working Like Infix Operator	
	var result = number isEqualTo 5  // number.isEqualTo( 5 )
	println("Result : $result")

	result = number isEqualTo 6 
	println("Result : $result")

	// Function Call Notation
	result = number.isEqualTo( 5 ) 
	println("Result : $result")

	// Infix Notation
	//		Binary Operator Comes In Between Two Operands 
	//		number and 10 Are Operands
	//	   	add Is Working Like Infix Operator	
	var resultAgain = number add 10 // number.add(10)
	println("ResultAgain : $resultAgain")

	resultAgain = number substract 5 
	println("ResultAgain : $resultAgain")

	resultAgain = number.add( 100 )
	println("ResultAgain : $resultAgain")

	resultAgain = number.substract( 100 )
	println("ResultAgain : $resultAgain")	
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("\nFunction : playWithPoints")
	playWithPoints()

	println("\nFunction : playWithUniaryIncrement")
	playWithUniaryIncrement()

	println("\nFunction : playWithPersonsComparision")
	playWithPersonsComparision()

	println("\nFunction : playWithMutablePoint")
	playWithMutablePoint()

	println("\nFunction : playWithOperatorIn")
	playWithOperatorIn()
	
	println("\nFunction : playWithInfixFunctions")
	playWithInfixFunctions()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/

