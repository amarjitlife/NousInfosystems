
____________________________________________________________

DAY 01
____________________________________________________________

	Assignment A1: Reading, Coding and Experimentation
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming


	CASE STUDIES: KOTLIN ADOPTION
		https://www.youtube.com/watch?v=hXfGybzWaiA
		https://www.jetbrains.com/help/kotlin-multiplatform-dev/case-studies.html
		https://kotlinlang.org/lp/server-side/case-studies/
		https://android-developers.googleblog.com/2022/08/celebrating-5-years-of-kotlin-on-android.html

____________________________________________________________

DAY 02
____________________________________________________________

	Assignment A1: Reading, Coding and Experimentation
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming

		Reference Book: Java Complete Reference
			Java Collections : Two Chapters

____________________________________________________________

DAY 03
____________________________________________________________

	Assignment A1: Java Reading, Coding and Experimentation [ MUST MUST ]
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming
			Chapter 03: Interfaces and Lambda Expressions
			Chapter 04: Inheritance and Reflection
			Chapter 07: Collections

		Reference Book: Java Complete Reference, By Herbert Schildt
			Java Collections : Two Chapters

	Assignment A2: Kotlin Reading, Coding and Experimentation
		Book: Kotlin Programming: The Big Nerd Ranch Guide Book (2nd Edition)
			First Four Chapters
			OR
		Book : Kotlin Head First
			First Four Chapters

	Assignment A3: Kotlin Revise, Practice Code Done In Class

____________________________________________________________

DAY 04
____________________________________________________________

	Assignment A1: Java Reading, Coding and Experimentation [ MUST MUST ]
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming
			Chapter 03: Interfaces and Lambda Expressions
			Chapter 04: Inheritance and Reflection
			Chapter 07: Collections

		Reference Book: Java Complete Reference, By Herbert Schildt
			Java Collections : Two Chapters

	Assignment A2: Kotlin Reading, Coding and Experimentation
		Book: Kotlin Programming: The Big Nerd Ranch Guide Book (2nd Edition)
			First Four Chapters
			OR
		Book : Kotlin Head First
			First Four Chapters

	Assignment A3: Kotlin Revise, Practice Code Done In Class


____________________________________________________________

DAY 05
____________________________________________________________

	Assignment A1: Kotlin Reading, Coding and Experimentation
		Book: Kotlin Programming: The Big Nerd Ranch Guide Book (2nd Edition)
			12. Defining Classes
			13. Initialization
			14. Inheritance
			16. Interfaces and Abstract Classes 

			OR 

		Book : Kotlin Head First
			4. classes and objects: A Bit of Class
			5. subclasses and superclasses: Using Your Inheritance
			6. abstract classes and interfaces: Serious Polymorphism
			7. data classes: Dealing with Data

	Assignment A2: Kotlin Revise, Practice, Experiment Code Done In Class


____________________________________________________________

DAY 06
____________________________________________________________

	Assignment A1: Kotlin Reading, Coding and Experimentation
		Book: Kotlin Programming: The Big Nerd Ranch Guide Book (2nd Edition)
			12. Defining Classes
			13. Initialization
			14. Inheritance
			16. Interfaces and Abstract Classes 

			OR 

		Book : Kotlin Head First
			4. classes and objects: A Bit of Class
			5. subclasses and superclasses: Using Your Inheritance
			6. abstract classes and interfaces: Serious Polymorphism
			7. data classes: Dealing with Data

	Assignment A2: Kotlin Revise, Practice, Experiment Code Done In Class


____________________________________________________________

DAY 07
____________________________________________________________

	Assignment A1: Kotlin Revise, Practice, Experiment Code Done In Class
		Read and Revise All The Topics Done Till Now
		Practice, Experiment and Revise Code Done Till Now

____________________________________________________________

DAY 08-10
____________________________________________________________

	Assignment A1: Kotlin Revise, Practice, Experiment Code Done In Class

	Assignment A2: Kotlin Reading, Coding and Experimentation
		Book: Kotlin Programming: The Big Nerd Ranch Guide Book (2nd Edition)
			Chapter 01 To Chapter 20 and Chapter 22
			
							OR 

		Book : Kotlin Head First
			02. basic types and variables: Being a Variable
			03. functions: Getting Out of Main
			04. classes and objects: A Bit of Class
			05. subclasses and superclasses: Using Your Inheritance
			06. abstract classes and interfaces: Serious Polymorphism
			07. data classes: Dealing with Data
			08. nulls and exceptions: Safe and Sound
			09. collections: Get Organized
			10. generics: Know Your Ins from Your Outs
			11. lambdas and higher-order functions: Treating Code Like Data
			12. built-in higher-order functions: Power Up Your Code
			A. coroutines: Running Code in Parallel
			C. leftovers: The Top Ten Things


	Assignment A3: Practice SpringBoot With Kotlin
		SpringBoot With Kotlin Tutorial	
			https://spring.io/guides/tutorials/spring-boot-kotlin
			https://github.com/spring-guides/tut-spring-boot-kotlin

	Assignment A4: Practice Exposed With Kotlin
		Exposed With Kotlin
			https://jetbrains.github.io/Exposed/getting-started-with-exposed.html
			https://jetbrains.github.io/Exposed/working-with-database.html
			https://jetbrains.github.io/Exposed/dsl-table-types.html
			https://jetbrains.github.io/Exposed/dsl-crud-operations.html
			https://jetbrains.github.io/Exposed/dsl-querying-data.html
			https://jetbrains.github.io/Exposed/table-definition.html

____________________________________________________________
____________________________________________________________

www.linkedin.com/in/amarjitlife
amarjitlife@gmail.com

____________________________________________________________
____________________________________________________________


