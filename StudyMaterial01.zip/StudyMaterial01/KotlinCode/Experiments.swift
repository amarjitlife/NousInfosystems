

let someInt: Int = 10
let someFloat : Float = 77.77

// error: binary operator '+' cannot be applied to operands of 
// type 'Int' and 'Float'
let someResult = Float( someInt ) + someFloat
print( someResult )

