
/* Commands
For Compiling Kotlin Code
kotlinc KotlinFoundation.kt -include-runtime -d foundation.jar

For Running JAR File
java -jar foundation.jar
*/

package learnKotlin

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// In Kotlin
//		By Default: Functions Returns Unit Value 

// Function hellWorld
//		Taking No Arguments and Returns Unit Value
fun helloWorld() {
	println("Hello World!!!")
}

fun playWithHelloWorld() {
	helloWorld()

	val result = helloWorld()
	println("Result : $result")
}
// Hello World!!!
// Hello World!!!
// Result : kotlin.Unit

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// In Kotlin : if-else Construct Is An Expression
// In Java : if-else Construct Is A Statement
// Expression: It's Is A Statement With Return Value

// Function
//		Takes Two Arguments Of Type Int
//		It Returns Value Of Int Type

// error: return type mismatch: 
//		expected 'kotlin.Unit', actual 'kotlin.Int'.
// fun max( a: Int, b: Int )  {
fun max( a: Int, b: Int ) : Int {
	return if ( a > b ) a else b
	// In java
	// if ( a <> b )
	// 	return a
	// else 
	// 	return b
}

// KotlinFoundation.kt:57:39: error: return type mismatch: 
//		expected 'kotlin.Unit', actual 'kotlin.Int'.
// fun maximum( a: Int, b: Int ): Unit = if ( a > b ) a else b

//	Implicit Type Inferring and Binding
// 1. Type Will Inferred From RHS Value
//			if-else Is An Expression
//			Expression Have Value
//			Every Value Have Type
//		In Following Code Inferred Type Of if-else Expression
			// Will Be Int
// 2. Inferred Type Is Binded With LHS Identifier
fun maximum( a: Int, b: Int )  = if ( a > b ) a else b

fun playWithMax() {
	// var Means Variable i.e. Mutable
	// val Means Constant i.e. IMMutable
	var result: Int

	result = max( 100, 200 )
	println("Result: $result")
	result = max( 900, 200 )
	println("Result: $result")

	result = maximum( 100, 200 )
	println("Result: $result")

	result = maximum( 900, 200 )
	println("Result: $result")
}

//_________________________________________________________

fun playWithTypes() {
	//	Implicit Type Inferring and Binding
	// 1. Type Will Inferred From RHS Value
	// 2. Inferred Type Is Binded With LHS Identifier
	val a = 99 //	99 Default Value Is Int
	println( a )

	// Explicit Type Annotation
	val aa : Int = 99
	println( aa )

	//	Implicit Type Inferring and Binding
	// 1. Type Will Inferred From RHS Value
	// 2. Inferred Type Is Binded With LHS Identifier
	val greeting = "Good Morning!"
	println( greeting )

	val greetingAgain = "Good Morning!"
	println( greetingAgain )

	val status = true
	println( status )

	val statusAgain: Boolean = true
	println( statusAgain )

	val some = 99.99
	println( some )

	val someAgain: Double = 99.99
	println( someAgain )

	val someInt: Int = 10
	val someFloat: Float = 77.77F

	// Implicit Type Conversion Happeing
	//		someInt Implicitly Type Casted To Float
	//		Hence RHS Value Will Be Float Type
	//		LHS Idenfitier Binded With Type Float
	val someResult = someInt + someFloat
	println( someResult )
}


//_________________________________________________________
// Kotlin Compiler Will Generate Following Things 
// For Person Class
//		1. It Will Generate Constructor
//				Memberwise Initialiser With Two Arguments
//				i.e. Person Class Have Two Properties
//		2. It Will Generate Two Member Variables/Fields
//				One Each For The Property
//				i.e. name And isMarried Are Properties
//		3. It Will Generate Getters/Setters For Each Property
//				Immutable Property Only Getter Generated
//				Mutable Property Both Getter and Setter Generated

// Created Person Class
class Person( val name: String, var isMarried: Boolean )

fun playWithPerson() {
	// Creating Two Instances/Objects Of Type Person Class
	val gabbar = Person("Gabbar", false )
	// Accessing Object Properties
	println( gabbar.name ) 		// gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()
	// error: 'val' cannot be reassigned.
	// gabbar.name = "Gabbar Singh"
	gabbar.isMarried = true  	// gabar.setIsMarried( true )
	println( gabbar.name ) 		// gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()

	val basanti = Person("Basanti", false )
	println( basanti.name )  // basanti.getName()
	println( basanti.isMarried )	// basanti.getIsMarried()
}

//_________________________________________________________

// Kotlin Compiler Will Generate Following Things 
//		1. It Will Generate Constructor
//				Memberwise Initialiser 
//				i.e. Rectangle Class Have Three Properties
//		2. It Will Generate Three Member Variables/Fields
//				One Each For The Property
//				i.e. name And isMarried Are Properties
//		3. It Will Generate Getters For Each Property
//				Immutable Property Only Getter Generated
//				Mutable Property Both Getter and Setter Generated
//				If Property Have Custom Getter Defined 
//					Than It Wont Be Generated

// Kotlin Compiler Will Generate Following Things For Rectangle Class
//		1. It Will Generate Constructor With Two Arguments With Int Type
//		2. It Will Generate Three Member Variables/Fields
//				Two For The Properties Int Type i.e. height And width
//				One For The Property Boolean Type i.e. isSquare
//				i.e. name And isMarried Are Properties
//		3. It Will Generate Getters For Two Properties i.e. height And width
//				Property Have Custom Getter Defined i.e. isSquare
//					Than It Wont Generate Getter

class Rectangle( val height: Int, val width: Int ) {
	val isSquare: Boolean
		get() { // Custom Getter
			println("isSquare Getter Called...")
			return height == width
		}
	// fun isSquare() : Boolean {
	// 	return height == width
	// }
}

class RectangleAgain( val height: Int, val width: Int ) {
	val isSquare: Boolean
		get() = height == width
}

class RectangleOnceAgain( val height: Int, val width: Int ) {
	// If Only Getter Directly Assign Body
	val isSquare: Boolean = height == width 
}

fun playWithRectangle() {
	val rectangle1 = Rectangle( 100, 100 )
	println( rectangle1.width )
	println( rectangle1.height )
	println( rectangle1.isSquare )
	// println( rectangle1.isSquare() )

	val rectangle2 = Rectangle( 200, 100 )
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare )	
	// println( rectangle2.isSquare() )	

	val rectangle3 = RectangleAgain( 300, 300 )
	println( rectangle3.width )
	println( rectangle3.height )
	println( rectangle3.isSquare )	
	// println( rectangle3.isSquare() )	

	val rectangle4 = RectangleOnceAgain( 300, 300 )
	println( rectangle4.width )
	println( rectangle4.height )
	println( rectangle4.isSquare )	
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("Function : playWithHelloWorld")
	playWithHelloWorld()

	println("Function : playWithMax")
	playWithMax()

	println("Function : playWithTypes")
	playWithTypes()

	println("Function : playWithPerson")
	playWithPerson()

	println("Function : playWithRectangle")
	playWithRectangle()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")	
	// println("Function : ")
}


// https://codebunk.com/b/2761100683827/
// https://codebunk.com/b/2761100683827/
// https://codebunk.com/b/2761100683827/

