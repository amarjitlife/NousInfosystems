/* Commands
For Compiling Kotlin Code
kotlinc HelloWorld.kt -include-runtime -d hello.jar

For Running JAR File
java -jar hello.jar
*/

package learnKotlin

fun main() {
	println("Hello World!!!")
}

// Kotlin Compiler Will Generate Following Code
// 		For Above Kotlin Code
	// class HelloWorldKt {
	// 	public static void main() {
	// 		System.out.println("Hello World!!!")
	// 	}
	// }

