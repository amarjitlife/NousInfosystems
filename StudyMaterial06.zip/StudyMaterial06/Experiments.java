

class SingletonClass {
	private static SingletonClass instance = null ;
	public String data;

	private SingletonClass() { data = "Created!"; }

	public static SingletonClass getInstance() {
		if ( instance == null ) 
			instance = new SingletonClass();

		return instance;
	}
}


class Experiments {
	public static void doSomething( int some ) {
		{
			// int some = 99;
			System.out.println( "Inside Function -> Some: " + some );		
		}
	}

	public static void playWithLocalVariables() {
		int some = 10;
		doSomething( some );

		if ( some == 10 ) {
			// int some = 100;
			System.out.println( "Inside If -> Some: " + some );		
		}
		System.out.println( "Outside If -> Some: " + some );				
		
		{
			int i = 10;
		}

		for ( int i = 0 ; i < 10 ; i++ ) {
			System.out.println( i );					
		}
	}

	public static void playWithSingleton() {
		SingletonClass first = SingletonClass.getInstance();

		System.out.println( first.data );
		first.data = "Assigned New Data";
		System.out.println( first.data );
	
		SingletonClass second = SingletonClass.getInstance();
		System.out.println( second.data );			
	}

	public static void main(String[] args) {
		System.out.println("Welcome Experiments!!!");

		System.out.println("\nFunction : playWithLocalVariables");
		playWithLocalVariables();

		System.out.println("\nFunction : playWithSingleton");
		playWithSingleton();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

