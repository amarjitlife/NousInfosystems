
____________________________________________________________

DAY 01
____________________________________________________________

	Assignment A1: Reading, Coding and Experimentation
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming


	CASE STUDIES: KOTLIN ADOPTION
		https://www.youtube.com/watch?v=hXfGybzWaiA
		https://www.jetbrains.com/help/kotlin-multiplatform-dev/case-studies.html
		https://kotlinlang.org/lp/server-side/case-studies/
		https://android-developers.googleblog.com/2022/08/celebrating-5-years-of-kotlin-on-android.html

____________________________________________________________

DAY 02
____________________________________________________________

	Assignment A1: Reading, Coding and Experimentation
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming

		Reference Book: Java Complete Reference
			Java Collections : Two Chapters

____________________________________________________________

DAY 03
____________________________________________________________

	Assignment A1: Java Reading, Coding and Experimentation [ MUST MUST ]
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming
			Chapter 03: Interfaces and Lambda Expressions
			Chapter 04: Inheritance and Reflection
			Chapter 07: Collections

		Reference Book: Java Complete Reference, By Herbert Schildt
			Java Collections : Two Chapters

	Assignment A2: Kotlin Reading, Coding and Experimentation
		Book: Kotlin Programming: The Big Nerd Ranch Guide Book (2nd Edition)
			First Four Chapters
			OR
		Book : Kotlin Head First
			First Four Chapters

	Assignment A3: Kotlin Revise, Practice Code Done In Class

____________________________________________________________

DAY 04
____________________________________________________________

	Assignment A1: Java Reading, Coding and Experimentation [ MUST MUST ]
		Reference Book: Java For Impatient, by Cay S. Horstmann (Author)
			Chapter 02: Object-Oriented Programming
			Chapter 03: Interfaces and Lambda Expressions
			Chapter 04: Inheritance and Reflection
			Chapter 07: Collections

		Reference Book: Java Complete Reference, By Herbert Schildt
			Java Collections : Two Chapters

	Assignment A2: Kotlin Reading, Coding and Experimentation
		Book: Kotlin Programming: The Big Nerd Ranch Guide Book (2nd Edition)
			First Four Chapters
			OR
		Book : Kotlin Head First
			First Four Chapters

	Assignment A3: Kotlin Revise, Practice Code Done In Class


____________________________________________________________

DAY 05
____________________________________________________________

	Assignment A1: Kotlin Reading, Coding and Experimentation
		Book: Kotlin Programming: The Big Nerd Ranch Guide Book (2nd Edition)
			12. Defining Classes
			13. Initialization
			14. Inheritance
			16. Interfaces and Abstract Classes 

			OR 

		Book : Kotlin Head First
			4. classes and objects: A Bit of Class
			5. subclasses and superclasses: Using Your Inheritance
			6. abstract classes and interfaces: Serious Polymorphism
			7. data classes: Dealing with Data

	Assignment A2: Kotlin Revise, Practice, Experiment Code Done In Class


____________________________________________________________

DAY 06
____________________________________________________________

	Assignment A1: Kotlin Reading, Coding and Experimentation
		Book: Kotlin Programming: The Big Nerd Ranch Guide Book (2nd Edition)
			12. Defining Classes
			13. Initialization
			14. Inheritance
			16. Interfaces and Abstract Classes 

			OR 

		Book : Kotlin Head First
			4. classes and objects: A Bit of Class
			5. subclasses and superclasses: Using Your Inheritance
			6. abstract classes and interfaces: Serious Polymorphism
			7. data classes: Dealing with Data

	Assignment A2: Kotlin Revise, Practice, Experiment Code Done In Class


____________________________________________________________

DAY 07
____________________________________________________________

	Assignment A1: Kotlin Revise, Practice, Experiment Code Done In Class
		Read and Revise All The Topics Done Till Now
		Practice, Experiment and Revise Code Done Till Now

____________________________________________________________

DAY 08
____________________________________________________________



____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________

