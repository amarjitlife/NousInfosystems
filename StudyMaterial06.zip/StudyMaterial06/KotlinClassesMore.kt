
/* Commands
For Compiling Kotlin Code
kotlinc KotlinClassesMore.kt -include-runtime -d more.jar

For Running JAR File
java -jar more.jar
*/

package learnKotlin

import java.util.Comparator
import java.io.File

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// class Person(val firstName: String, val lastName: String ) {
// open class Person(val firstName: String, val lastName: String ) {
// open class Person(open val firstName: String, open val lastName: String ) {
// 		open val fullName = "$firstName $lastName"
// }

open class Person( val firstName: String, val lastName: String ) {
	val fullName = "$firstName $lastName"
}

// class Student(val firstName: String, val lastName: String ) : Person(firstName, lastName) {
// class Student(override val firstName: String, override val lastName: String ) 
// 	: Person(firstName, lastName) {
// 		override val fullName = "$firstName $lastName"
// } 

data class Subject( val name: String, val grade: Char, val points: Double, val credits: Double)

open class Student( firstName: String, lastName: String ) : Person(firstName, lastName) {
	val passedSubjects: MutableList<Subject> = mutableListOf<Subject>()
	val failedSubjects: MutableList<Subject> = mutableListOf<Subject>()	

	fun recordGrade( subject: Subject ) {
		if ( subject.grade == 'F' ) failedSubjects.add( subject )
		else passedSubjects.add( subject )
	}

	open fun printGrades() {
		for ( subject in passedSubjects ) println( "  $subject")
		for ( subject in failedSubjects ) println( "  $subject")		
	}

	fun isPassed() : Boolean {
		return failedSubjects.size <= 2 
	}
} 


fun playWithClasses() {
	val gabbar = Person("Gabbar", "Singh")
	println( gabbar.fullName )

	val basanti = Person( firstName = "Basanti", lastName = "Chatty")
	println( basanti.fullName )	

	val veeru = Student("Veeru", "Dharam")
	println( veeru.fullName )

	val jay = Student("Jay", "Amitabh")
	println( jay.fullName )
}

fun playWithStudentGrades() {
	val gabbar = Student("Gabbar", "Singh")

	val decoit = Subject("Decoit", 'A', points = 9.0 , credits = 3.0 )
	//					Named Arugments
	val kiddnapping = Subject( name = "kiddnapping", grade = 'A' , points = 10.0, credits = 3.0)
	val shooting = Subject("Shooting", 'B', 8.0, credits = 4.0)

	gabbar.recordGrade( decoit )
	gabbar.recordGrade( kiddnapping )
	gabbar.recordGrade( shooting )
	println( gabbar.fullName )
	gabbar.printGrades() 

	val basanti = Student("Basanti", "Chatti")
	val english = Subject("English", 'C', points = 7.0, credits = 3.0 )
	basanti.recordGrade( english )
	println( basanti.fullName )
	basanti.printGrades()
}

// Function : playWithClasses
// Gabbar Singh
// Basanti Chatty
// null null
// null null

//_________________________________________________________

data class Game(val name: String, val grade: Char, val points: Double )

class StudentAthlete(firstName: String, lastName: String) : Student( firstName, lastName ) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGames( game: Game ) = gamesPlayed.add( game )

	override fun printGrades() {
		super.printGrades()
		for( game in gamesPlayed ) println("  $game")
	}
}


fun playWithStudentAthlete() {
	val gabbar = StudentAthlete("Gabbar", "Singh")

	val decoit = Subject("Decoit", 'A', points = 9.0 , credits = 3.0 )
	//					Named Arugments
	val kiddnapping = Subject( name = "kiddnapping", grade = 'A' , points = 10.0, credits = 3.0)
	val shooting = Game("Shooting", 'B', 8.0)

	gabbar.recordGrade( decoit )
	gabbar.recordGrade( kiddnapping )
	gabbar.recordGames( shooting )
	println( gabbar.fullName )
	gabbar.printGrades() 

	val basanti = StudentAthlete("Basanti", "Chatti")
	val english = Subject("English", 'C', points = 7.0, credits = 3.0 )
	val dancing = Game("Dancing", 'A', 10.0)

	basanti.recordGrade( english )
	basanti.recordGames( dancing )
	println( basanti.fullName )
	basanti.printGrades()
}

//_________________________________________________________

open class BandMember(firstName: String, lastName: String ) : Student( firstName, lastName ) {
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember( firstName, lastName ) {
	override val minimumPracticeTime: Int 
		get() { return 4 }
}

class FlutePlayer(firstName: String, lastName: String) : BandMember( firstName, lastName ) {
	override val minimumPracticeTime: Int 
		get() { return 3 }
}

fun playWithTypeCheck() {
	//	LHS  						=  RHS
	// Reference To Object ------->   Object [Allocated At Heap ]
	// Reference guitarPlayer Of Type GuitarPlayer Pointing To Object Of Type GuitarPlayer
	val guitarPlayer : GuitarPlayer = GuitarPlayer("Gabbar", "Singh")

	// is Type Check
	//	Doing Type Check Of Reference OR Object Where Reference Pointing
	//	is Type Check Does Checking Of OBJECT
	println( guitarPlayer is GuitarPlayer )
	println( guitarPlayer is BandMember )
	println( guitarPlayer is Student )
	println( guitarPlayer is Person )

	// Reference reference1 Of Type GuitarPlayer Pointing To Object Of Type GuitarPlayer	
	val reference1 = guitarPlayer
	// Reference reference2 Of Type BandMember Pointing To Object Of Type GuitarPlayer	
	val reference2: BandMember 	= guitarPlayer	
	// Reference reference3 Of Type Student Pointing To Object Of Type GuitarPlayer	
	val reference3: Student 	= guitarPlayer
	// Reference reference4 Of Type Person Pointing To Object Of Type GuitarPlayer	
	val reference4: Person 		= guitarPlayer

	println( reference1 is GuitarPlayer )
	println( reference1 is BandMember )
	println( reference1 is Student )
	println( reference1 is Person )

	println( reference2 is GuitarPlayer )
	println( reference2 is BandMember )
	println( reference2 is Student )
	println( reference2 is Person )

	println( reference3 is GuitarPlayer )
	println( reference3 is BandMember )
	println( reference3 is Student )
	println( reference3 is Person )

	// Reference shakira Of Type BandMember Pointing To Object Of Type BandMember	
	val shakira = BandMember("Shakira", "Waka Waka")
	println( shakira is GuitarPlayer )
	println( shakira is BandMember )
	println( shakira is Student )
	println( shakira is Person )

	val milkha = StudentAthlete("Milkha", "Singh" )
	println( milkha is Student )
	println( milkha is Person )
	println( milkha is GuitarPlayer )
	println( milkha is BandMember )	
}

//_________________________________________________________

interface Something {
	fun doSomething() = println("Something: Do Something")
}

interface Clickable {
	fun click() // Abstract Member Function: Function With ONLY Signature
	fun doFun() = println("Clickable: Do Fun!") // NOT A ABSTRACT Member Function
}

interface Focusable {
	fun focus() // Abstract Member Function: Function With Signature
}

class Button : Clickable, Focusable, Something {
	override fun click() = println("Button: click Called...")
	override fun focus() = println("Button: focus Called...")
	override fun doFun() = println("Button: Do Fun!")
	fun doMagic() = println("Button: Doing Magic...")

	override fun doSomething() {
		super.doSomething()
		println("Button1: Do Something!")
	}
}

fun playWithTypeCheckAgain() {
	val button = Button()

	println( button is Button )
	println( button is Clickable )
	println( button is Focusable )
	println( button is Something )
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

abstract class Mammal( val name: String, val birthDate: String ) {
	abstract fun consumeFood()
}


class Human( name: String, birthDate: String ) : Mammal( name, birthDate ) {
	override fun consumeFood() {
		println("Human: Consuming Food...")
	}

	fun createBirthCertificate() = println("Birth Certificate Created!")
}

fun playWithMammals() {
	val katrina = Human("Katrina Kaif", "10-10-10")
	katrina.consumeFood()
	katrina.createBirthCertificate()

	println( katrina is Human )
	println( katrina is Mammal )
}

//_________________________________________________________

sealed class Geometry {
	class Circle( val radius: Int ) : Geometry()
	class Square( val side: Int ) 	: Geometry()
	class Unknown( val size: Int ) 	: Geometry()
}

fun sizeOfGeometry( geometry: Geometry ) = when( geometry ) {
		is Geometry.Circle 	-> geometry.radius
		is Geometry.Square 	-> geometry.side
		is Geometry.Unknown -> geometry.size 
}

fun playWithGeometries() {
	val circle = Geometry.Circle( 10 )
	val square = Geometry.Square( 99 )

	println( sizeOfGeometry( circle ) )
	println( sizeOfGeometry( square ) )
}

//_________________________________________________________

//PRIMARY CONSTRUCTOR AND SECONDARY CONSTRUCTORS

// 				Primary Constructor
class PersonAgain1(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
}

// 				Primary Constructor
//		constructor Keyword Is Optional For Primary Constructor
class PersonAgain2 constructor(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
}

// Above PersonAgain1 and PersonAgain2 Are Equivalent
class PersonOnceAgain {
	val firstName: String = "Unknown"
	val lastName: String  = ""
	val fullName = "$firstName $lastName"
}

fun playWithConstructors() {
	val gabbar1 = PersonAgain1("Gabbar", "Singh")
	println( gabbar1.fullName )

	val gabbar2 = PersonAgain2("Gabbar", "Singh")
	println( gabbar2.fullName )


	// val gabbar1 = PersonAgain()
	// println( gabbar1.fullName )

				   // DEFUALT CONSTRUCTOR
	val basanti = PersonOnceAgain()
	println( basanti.fullName )
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// BEST PRACTICE
//		Always Prefer Primary COnstructor With Default Arguments
//			Over Constructor Overloading

//				 Primary Constructor With Default Arguments
class ShapeBetter( var boundaryColor: String, var fillColor : String = "Unknown" ) {
	fun printData() {
		println("ShapeBetter :: boundaryColor = $boundaryColor, fillColor = $fillColor")
	}	
}

// SECONDARY CONSTRUCTORS
//		Constructor Overloading
open class Shape {
	var boundaryColor : String
	var fillColor : String

	// CONVENINCE CONSTRUCTOR
	// Secondary Constructor
	// constructor( boundaryColor : String ) {	
	constructor( boundaryColor : String ) : this(boundaryColor, "Unknown") {
		// this.boundaryColor = boundaryColor
		// this.fillColor = "Uknonwn"
	} 

	// FULL CONSTRUCTOR
	// Secondary Constructor
	constructor( boundaryColor : String, fillColor : String ) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
	} 

	open fun printData() {
		println("Shape :: boundaryColor = $boundaryColor, fillColor = $fillColor")
	}
}

fun playWithShape() {
	val shape1 = Shape("Black")
	shape1.printData()

	val shape2 = Shape("Black", "Green")
	shape2.printData()

	val shape11 = ShapeBetter("Black")
	shape11.printData()

	val shape22 = ShapeBetter("Black", "Green")
	shape22.printData()
}

//_________________________________________________________

class Circle : Shape {
	var radius : Int

	// DESIGN 01
	// constructor( boundaryColor : String ) {
		// error: explicit 'this' or 'super' call is required. 
		//		There is no constructor in the superclass that can be called without arguments.
	//DESIGN 02
	// constructor( boundaryColor : String ) : super( boundaryColor ) {

	//DESIGN 03: CONVIENCE CONSTRUCTOR
	//		It Should Call FULL CONSTRUCTOR WITHIN SAME CLASS
	constructor( boundaryColor : String ) : this( boundaryColor, "Unknown", 0 ) {
		// this.boundaryColor = boundaryColor
		// this.fillColor = "Unknown"
		// this.radius = 0
	}

	//DESIGN 03: CONVIENCE CONSTRUCTOR
	//		It Should Call FULL CONSTRUCTOR WITHIN SAME CLASS
	constructor( boundaryColor : String, fillColor: String ) : this( boundaryColor, fillColor, 0 ) {
		// this.boundaryColor = boundaryColor
		// this.fillColor = fillColor
		// this.radius = 0
	}

	// FULL CONSTRUCTOR : WHich Initiases Object Fully i.e. All Properties Intialised
	//		Initialisation Logic Maintained At One Place
	//		FULL CONSTRUCTOR From Child Class Should Call FULL CONSTRUCTOR From Parent Class
	constructor( boundaryColor : String, fillColor: String, radius: Int ) : super(boundaryColor, fillColor) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
		this.radius = radius
	}

	override fun printData() {
		println("Circle :: BoundryColor= $boundaryColor, FillColor = $fillColor, Radius = $radius")
	}
}

fun playWithShapeAndCircle() {
	val shape1 = Shape("Black")
	shape1.printData()

	val shape2 = Shape("Black", "Green")
	shape2.printData()


	val circle1 = Circle("Black")
	circle1.printData()

	// val circle2 = Circle("Black", "Red")
	// circle2.printData()

	val circle3 = Circle("Black", "Green", 10)
	circle3.printData()
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun playWithLocalFunctionAndClasses() { // Outside Context/Function
	var something = 10 
	// Local Function: Function Defined Inside Function
	//		Inside Context Always Captures The Outside Context
	fun doSomething() { // Inside Context/Function
		println("Function: doSomething")
		println("Accessing Inside: $something")
		// Modifiying Outside Context/Function From Inside Context/Function
		//		These Changes Will Reflect Back To Outside Context/Function
		something = 111
		println("Accessing Inside: $something")
	}

	// Local Class: Class Defined Inside Function
	class Person( val firstName: String, val lastName: String ) { //Inside Context/Class
	//		Inside Context Always Captures The Outside Context
		val somethingAgain = something + 100
		val fullName = "$firstName $lastName"
		// Member Functions
		fun doDance() = println("$fullName Doing Dance...")
		fun doSomething() {
			println("Person: doSomething: $somethingAgain")
		}
	}

	doSomething()
	println("Accessing Outside: $something")

	val gabbar = Person("Gabbar", "Singh")
	println(gabbar.fullName)
	gabbar.doDance()
	gabbar.doSomething()

	println("Accessing Outside: $something")
}

// Function : playWithLocalFunctionAndClasses
// Function: doSomething
// Accessing Inside: 10
// Accessing Inside: 111
// Accessing Outside: 111
// Gabbar Singh
// Gabbar Singh Doing Dance...
// Person: doSomething: 211
// Accessing Outside: 111

//_________________________________________________________
// Visibility Modifiers

data class Privilege( val id: Int, val name: String )

open class User( 
	val firstName: String, 
	val lastName: String, 
	protected var age: Int, 
	private var aadharCard: Int 
)

class PrivilegedUser( 
	firstName: String, 
	lastName: String, 
	age: Int, 
	aadharCard: Int 
) : User( firstName, lastName, age, aadharCard ) {

	private val privileges = mutableListOf<Privilege>()

	fun addPrivlege( privilege: Privilege ) {
		privileges.add( privilege )
	}

	fun printPrivileges() {
		for ( privilege in privileges ) {
			println("    $privilege")
		}
	}

	fun details()= println( "Name: $firstName, $lastName, Age: $age")
}

fun playWithPrivilegedUser() {
	val privilegedUser = PrivilegedUser( firstName = "Alice", lastName = "Carols", 23, 999999 )
	val invisiblePrivilege = Privilege( id = 11, name = "Can Be Invisible!")
	val immortalePrivilege = Privilege( id = 999, name = "Can Become Immortal!")

	privilegedUser.addPrivlege( invisiblePrivilege )
	privilegedUser.addPrivlege( immortalePrivilege )
	privilegedUser.details()
	privilegedUser.printPrivileges()
}

//_________________________________________________________
// NESTED AND INNER CLASSES

// Hands On Following Code, Moment Done Raise Your Hands!!!
// 1. Complete Hands On Code In Kotlin
// 2. Write Following Code In Java
class Car( val carName: String ) { // Outside Context/Class
	val steering: Int = 0
	var wheels: Int = 4
	val something = 99 
	// Defining NESTED Class
	// Nested Class
	//		Class Defined Inside Another Class
	//		Nested Classes Can't Access Outside Context	
	// In Kotlin Inside Classes Are NESTED By Default
	//		Nested Classes Can't Access Outside Context
	// In Java Inside Classes Are INNER By Default
	//		Inner Classes CAN Access Outside Context
	class Engine( val engineName: String ) { //Inside Context/Class
		override fun toString() : String {
			//  error: unresolved reference 'something'
			// println("Something : $something")
			return "Engine(engineName=$engineName)"
			 // error: unresolved reference 'carName'
			// return "Engine(engineName=$engineName) In Car: $carName"
		}
	}

	override fun toString() : String {
		return "Car(carName=$carName, wheels=$wheels)"
	}
}

class CarAgain( val carName: String ) { // Outside Context/Class
	val steering: Int = 0
	var wheels: Int = 4
	val something = 99 	
	// Defining NESTED Class
	// Inner Class
	//		Class Defined Inside Another Class
	//		Inner Classes CAN Access Outside Context
	// In Kotlin Inside Classes Are NESTED By Default
	//		Nested Classes Can't Access Outside Context
	// In Java Inside Classes Are INNER By Default
	//		Inner Classes CAN Access Outside Context
	inner class Engine( val engineName: String ) { //Inside Context/Class
		override fun toString() : String {
			println("Something : $something")
			return "Engine(engineName=$engineName) In Car: $carName"
		}
	}

	override fun toString() : String {
		return "Car(carName=$carName, wheels=$wheels)"
	}
}

fun playWithNestedAndInnerClasses() {
	val swiftCar = Car("Swift")
	val swiftEngine = Car.Engine("Fiat")

	println( swiftCar )
	println( swiftEngine )

	val swiftCarAgain = CarAgain("Swift")
	val swiftEngineAgain = swiftCarAgain.Engine("Fiat")
	println( swiftCarAgain )
	println( swiftEngineAgain ) 
}


//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// import java.util.Comparator
// import java.io.File

object CaseInsensitiveFileComparator : Comparator<File> {
	override fun compare( file1: File, file2: File ) : Int {
		return file1.path.compareTo( file2.path, ignoreCase = true )
	}
}

fun playWithCaseInsensitiveComparator() {
	val result = CaseInsensitiveFileComparator.compare(
		File("/User/gabbar/Documents/"),
		File("/User/Gabbar/Documents/")
	)

	println("Result: $result ")

	val files = listOf( File("/User/Documents"), File("/z"), File("/usr"), File("/bin"))
	val sortedFiles = files.sortedWith( CaseInsensitiveFileComparator )
	println( sortedFiles )
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

data class PersonMore( val name : String, val age: Int ) {
	object NameComparator : Comparator<PersonMore> {
		override fun compare( p1: PersonMore, p2: PersonMore ) : Int = p1.name.compareTo( p2.name )
	}

	object AgeComparator : Comparator<PersonMore> {
		override fun compare( p1: PersonMore, p2: PersonMore ) : Int = p1.age.compareTo( p2.age )
	}

}

fun playWithPersonMore() {
	val persons = listOf( PersonMore("Gababr", 40), PersonMore("Veeru", 28), PersonMore("Jay", 30) )
	println( persons.sortedWith( PersonMore.NameComparator ) )
	println( persons.sortedWith( PersonMore.AgeComparator ) )	
}

//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

// 1. Complete Hands On Code In Kotlin
// 2. Write Following Code In Java

class SomeClass {
	companion object {
		// Class/Type Members
		val somethingMore = 999
		fun doMagic() {
			println("Companion Object: Doing Magic")
		}
	}

	// Instance/Object Members
	val something = 99
	fun doSomething() {
		println("SomeClass: Doing Something")
	}
}

fun playWithCompanionObject() {
	val some = SomeClass()
	some.doSomething()
	println( some.something )

	SomeClass.doMagic()
	println( SomeClass.somethingMore )
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
// Hands On Following Code, Moment Done Raise Your Hands!!!

fun main() {
	println("\nFunction : playWithClasses")
	playWithClasses()

	println("\nFunction : playWithStudentGrades")
	playWithStudentGrades()

	println("\nFunction : playWithStudentAthlete")
	playWithStudentAthlete()

	println("\nFunction : playWithTypeCheck")
	playWithTypeCheck()

	println("\nFunction : playWithTypeCheckAgain")
	playWithTypeCheckAgain()

	println("\nFunction : playWithMammals")
	playWithMammals()

	println("\nFunction : playWithGeometries")
	playWithGeometries()

	println("\nFunction : playWithConstructors")
	playWithConstructors()

	println("\nFunction : playWithShape")
	playWithShape()

	println("\nFunction : playWithShapeAndCircle")
	playWithShapeAndCircle()

	println("\nFunction : playWithLocalFunctionAndClasses")
	playWithLocalFunctionAndClasses()

	println("\nFunction : playWithPrivilegedUser")
	playWithPrivilegedUser()

	println("\nFunction : playWithNestedAndInnerClasses")
	playWithNestedAndInnerClasses()

	println("\nFunction : playWithCaseInsensitiveComparator")
	playWithCaseInsensitiveComparator()

	println("\nFunction : playWithPersonMore")
	playWithPersonMore()

	println("\nFunction : playWithCompanionObject")
	playWithCompanionObject()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
https://codebunk.com/b/3101100684027/
*/
